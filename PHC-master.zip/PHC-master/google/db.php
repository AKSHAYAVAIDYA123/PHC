<?php
$username="root";
$password=" ";
$database="medical";
?>
