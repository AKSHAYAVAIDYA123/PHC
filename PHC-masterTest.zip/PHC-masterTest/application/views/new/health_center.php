<!DOCTYPE html>
<html>


          <?php
              require('side_menu.html');
          ?>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Primary Health Center (PHC)
            <small>Enter Details</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row" style="background:#21D380">
            <div class="box box-primary" >
              <div class="col-md-3" style="background:#21D380">
              </div>
              <!-- form start -->
              <?php

              echo form_open('Add_details/add_phc'); ?>
                  <div class="col-md-6" style="background:#21D380">
                  <div class="box-body" >

                    <div class="form-group">
                      <label>PHC Code<span style="color:red">&nbsp*</span></label>  <span style="color:red;" id="code_status"></span>
                      <input type="text" id="phc_code" class="form-control"  name="phc_code" placeholder="Enter PHC Code" required="" onkeyup="check_phc();">

                    </div>

                    <div class="form-group">
                      <label>PHC Name<span style="color:red">&nbsp*</span></label>
                      <input type="text" class="form-control" name="phc_name" placeholder="Enter PHC Name" required="">
                    </div>
                    <div class="form-group">
                      <label>PHC Address<span style="color:red">&nbsp*</span></label>

                      <textarea class="form-control"  rows="3" name="phc_addr" placeholder="Enter PHC Address..." required=""></textarea>
                    </div>

                    <div class="form-group">
                      <label>PHC Phone No<span style="color:red">&nbsp*</span></label>
                      <input type="tel" pattern="^\d{12}$"  maxlength="12" class="form-control" name="phc_phn" placeholder="Enter PHC Phone No" required="">
                    </div>

                </div><!-- /.box-body -->
                <div class="box-footer" style="background:#21D380">
                    <input type="submit" value="Submit" name="submit"  class="btn btn-danger pull-right">
                </div>
                </div>
            <?php  form_close(); ?>
            <div class="col-md-3">
            </div>
            </div><!-- /.box -->
          </div>
    </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
  <?php require('footer.html');?>

  </body>

</html>
