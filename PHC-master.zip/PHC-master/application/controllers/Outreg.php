<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Outreg extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct() {
     parent::__construct();
		 $this->load->database();
		 $this->load->model(array('Add_model','Fetch_model','User_model','Update_model','Csv_model'));
		 $this->load->library('session');
			$this->load->helper('url');
   }

	  public function index(){
			if(isset($_POST['submit']) && !empty($_POST['submit'])){
			if($this->session->userdata('Login')){
					 $session=$this->session->userdata('Login');
					 $user['user_id']=$session['id'];
					 $user['email']=$session['email'];
					 $user['name']=$session['name'];
					 $user['role']=$session['role'];
					 $user['phc_code']=$session['phc_code'];
					if($this->input->post('nrkp')==1)
					{
						$nrk=$this->input->post('nrkpid');
					}else{
						$nrk="No";
					}


					$s_no= $this->User_model->get_s_no($user['phc_code']);
					$var = 0;
					foreach ($s_no as $key) {
						$var = $key['s'];
					}
					$var=$var+1;
					 $data = array(
							 'date_fv' => $this->input->post('date_fv'),
							 'pat_name' => $this->input->post('pat_name'),
							 'pat_addrs' => $this->input->post('addr'),
							 'pat_father' => $this->input->post('ct'),

							 'rhc_id' => $this->input->post('phc'),
							 'sex' => $this->input->post('sex'),
							 'age' => $this->input->post('age'),
							 'phno' => $this->input->post('phn'),

							 'pat_no'=>sprintf("%06d",$var),//input->post('phc').date("ymdHis"),
							 'nrkid'=>$nrk,
							 'pat_place' => $this->input->post('pat_place'),
							 'pat_lat' => $this->input->post('lat'),
							 'pat_long' => $this->input->post('long'),



				 );
				 	$val= array();
				 $auto_id=$this->User_model->insert_user($data);
				 foreach ( $auto_id as $row) {
					 $val=$row['pat_no'];
				 }

				 $us=base64_encode($val);

			 redirect('Myhome/out_reg/'.$us,'refresh');


			 }else{
				 redirect('/', 'refresh');
			 }

    }
}

public function Add_precord(){
	if(isset($_POST['submit']) && !empty($_POST['submit'])){
		if($this->session->userdata('Login')){
			$session=$this->session->userdata('Login');
			$user['user_id']=$session['id'];
			$user['email']=$session['email'];
			$user['name']=$session['name'];
			$user['role']=$session['role'];
			$user['phc_code']=$session['phc_code'];

			$op_fileno=$this->input->post('pat_no');
			$complaints=$this->input->post('compl');
			$treatment = $this->input->post('drug_id');
			$quantity = $this->input->post('qunt');
			$dq = $this->input->post('drug_qty');
			$findings = $this->input->post('Findings');
			$diagonosis = $this->input->post('diag');
			$investigation = $this->input->post('invest');
			$treat = $this->input->post('treat');
			$reference  = $this->input->post('ref');
			$visit_type = $this->input->post('trt_type');
			$dt=date('Y-m-d');

		 	for($i=0;$i<count($treatment);$i++){
		 			$data = array('op_fileno' =>$op_fileno,'complaints' => $complaints ,'drug_id' => $treatment[$i],'quantity' => $quantity[$i],'phc'=>$user['phc_code'],'rem'=>($dq[$i]),'findings'=>$findings,'diagonosis'=>$diagonosis,'investigation'=>$investigation,'treatment'=>$treat,'reference'=>$reference,'visit_type'=>$visit_type);
					$result=$this->User_model->insert_record($data);
					$result1=$this->User_model->update_drug_qty($treatment[$i],$quantity[$i],$user['phc_code']);
 				}
				if($this->input->post('pat_sex')=='Male'){
					$x='1';
				}else{
					$x='2';
				}
				$rec =  array(
					'reffered_to' => $reference,
					'pat_id' => $result,
					'op_file_no' => $op_fileno,
					'phc_id' => $user['phc_code'],
					'pat_name' => $this->input->post('pat_name'),
					'pat_age' => $this->input->post('pat_age'),
					'pat_sex' => $x,
					'diagnosis' => $diagonosis,

				 );
			$ref_result=$this->User_model->insert_ref_record($rec);

		 if(($result)&&($result1==1)&&($ref_result)){
				$this->session->set_flashdata('in',1);
			  redirect('Myhome/pat_hist','refresh');
		 }else{
			 ?>
			<script>alert("Failed");</script>
			<?php
				$us=base64_encode($op_fileno);
				redirect('Myhome/pat_hist','refresh');
			}
	 	}else{
		 redirect('/', 'refresh');
	 }
	}
}

public function edit_precord(){
	if(isset($_POST['submit']) && !empty($_POST['submit'])){
		if($this->session->userdata('Login')){
			$session=$this->session->userdata('Login');
			$user['user_id']=$session['id'];
			$user['email']=$session['email'];
			$user['name']=$session['name'];
			$user['role']=$session['role'];
			$user['phc_code']=$session['phc_code'];

			$pr_id=$this->input->post('id');
			$name=$this->input->post('pat_name');
			$father = $this->input->post('pat_fn');
			$op_id = $this->input->post('pat_no');
			$age = $this->input->post('pat_age');
			$sex = $this->input->post('pat_sex');
			$pat_addrs = $this->input->post('pat_addrs');
			$nrkid = $this->input->post('nrkid');
			$dt=date('Y-m-d');

		/* for($i=0;$i<count($treatment);$i++){
		 			$data = array('op_fileno' =>$op_fileno,'complaints' => $complaints ,'drug_id' => $treatment[$i],'quantity' => $quantity[$i],'phc'=>$user['phc_code'],'rem'=>($dq[$i]),'findings'=>$findings,'diagonosis'=>$diagonosis,'investigation'=>$investigation,'treatment'=>$treat,'reference'=>$reference );
					$result=$this->User_model->insert_record($data);
					$result1=$this->User_model->update_drug_qty($treatment[$i],$quantity[$i],$user['phc_code']);
 				}
				if($this->input->post('pat_sex')=='Male'){
					$x='1';
				}else{
					$x='2';
				}*/
				$rec =  array(
					'pat_name' => $name,
					'pat_addrs'=> $pat_addrs,
					'pat_father' => $father,
					'sex' => $sex,
					'age' => $age ,
					'pat_no' => $op_id,
					'nrkid' => $nrkid

				 );
			$result=$this->User_model->edit_patient_record($rec,$pr_id,$user['phc_code']);

		 if(($result)){
				$this->session->set_flashdata('in',1);
			  redirect('Myhome/edit_pat_hist','refresh');
		 }else{
			 ?>
			<script>alert("Failed");</script>
			<?php
				$us=base64_encode($op_fileno);
				redirect('Myhome/edit_pat_hist','refresh');
			}
	 	}else{
		 redirect('/', 'refresh');
	 }
	}
}


public function lab_patients(){
	if(isset($_POST['submit']) && !empty($_POST['submit'])){
	if($this->session->userdata('Login')){
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
		/*	if($this->input->post('nrkp')==1)
			{
				$nrk=$this->input->post('nrkpid');
			}else{
				$nrk="No";
			}*/
			 $data = array(
					// 'date_fv' => $this->input->post('date_fv'),
					 'pat_name' => $this->input->post('pat_name'),
					 'lab_no' => $this->input->post('lab_no'),
					 'hospital_no' => $this->input->post('hospital_no'),
					 'age' => $this->input->post('age'),
					 'sex' => $this->input->post('sex'),
					 'dept' => $this->input->post('dept'),
					 'op_no'=>$this->input->post('op_ip_no'),
					 'spl_test'=>$this->input->post('spl_test')
					// 'nrkid'=>$nrk,
					// 'pat_place' => $this->input->post('pat_place'),
					 //'pat_lat' => $this->input->post('lat'),
					 //'pat_long' => $this->input->post('long'),
 			 );
			$val= array();
		 $auto_id=$this->User_model->insert_lab_record($data);
		 foreach ( $auto_id as $row) {
			 $val=$row['pat_id'];
		 }
		 $lab_tests = $this->input->post('test');
		 $v =array();
		 foreach ($lab_tests as $key => $value) {

		 	$res= $this->User_model->lab_pat_record($val,$value);
		 }

		/* $us=base64_encode($val);*/
		if(($auto_id)&&($res)){
			$this->session->set_flashdata('in',1);
			redirect('Myhome/choice','refresh');
		}else{
			?>
		 <script>alert("Failed");</script>
		 <?php
				redirect('Myhome/choice','refresh');
		 }


	 }else{
		 redirect('/', 'refresh');
	 }

}
}

public function lab_patients_ref(){
	if(isset($_POST['submit']) && !empty($_POST['submit'])){
	if($this->session->userdata('Login')){
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
		/*	if($this->input->post('nrkp')==1)
			{
				$nrk=$this->input->post('nrkpid');
			}else{
				$nrk="No";
			}*/
			if($this->input->post('pat_sex')=='Male'){
				$x='1';
			}else{
				$x='2';
			}
			 $data = array(
					// 'date_fv' => $this->input->post('date_fv'),
					 'pat_name' => $this->input->post('pat_name'),
					 'lab_no' => $this->input->post('lab_no'),
					 'hospital_no' => $this->input->post('hospital_no'),
					 'age' => $this->input->post('age'),
					 'sex' => $x,
					 'dept' => $this->input->post('dept'),
					 'op_no'=>$this->input->post('op_ip_no'),
					 'spl_test'=>$this->input->post('spl_test'),
					 'if_ref' =>1,
					 'refer_id' =>$this->input->post('pat_id')
					// 'nrkid'=>$nrk,
					// 'pat_place' => $this->input->post('pat_place'),
					 //'pat_lat' => $this->input->post('lat'),
					 //'pat_long' => $this->input->post('long'),
 			 );

			$val= array();
		 $auto_id=$this->User_model->insert_lab_record($data);
		 foreach ( $auto_id as $row) {
			 $val=$row['pat_id'];
		 }
		 $lab_tests = $this->input->post('test');
		 $v =array();
		 foreach ($lab_tests as $key => $value) {

		 	$res= $this->User_model->lab_pat_record($val,$value);
		 }

		/* $us=base64_encode($val);*/
		if(($auto_id)&&($res)){
			$this->session->set_flashdata('in',1);
		 	redirect('Myhome/choice','refresh');
		}else{
			?>
		 <script>alert("Failed");</script>
		 <?php
				redirect('Myhome/choice','refresh');
		 }


	 }else{
		 redirect('/', 'refresh');
	 }

}
}
public function lab_patients_ref1(){
	if(isset($_POST['submit']) && !empty($_POST['submit'])){
	if($this->session->userdata('Login')){
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];


					// 'date_fv' => $this->input->post('date_fv'),
					 $test_result = $this->input->post('test_res');
					 $lab_pat_id = $this->input->post('test_res_id');

					 for($i=0;$i<count($test_result);$i++){
						$result=$this->Add_model->update_test_res($test_result[$i],$lab_pat_id[$i]);
					 }
		/* $us=base64_encode($val);*/
		if($result){
			$this->session->set_flashdata('in',1);
		 	redirect('Myhome/choice','refresh');
		}else{
			?>
		 <script>alert("Failed");</script>
		 <?php
				redirect('Myhome/choice','refresh');
		 }


	 }else{
		 redirect('/', 'refresh');
	 }

}
}


}
?>
