<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Csv_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function insertCSV($data)
            {
                $this->db->insert('all_drugs', $data);
                return TRUE;
            }



    public function view_data(){
        $query=$this->db->query("SELECT * FROM all_drugs ");
        return $query->result_array();
    }

}
