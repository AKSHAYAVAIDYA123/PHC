<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model
{
	function __construct()
    {
        parent::__construct();

    }

	function get_user($email, $pwd)
	{
		$q=$this->db->query("Select * from users where email='$email' and password='$pwd'");

		if( $q->num_rows() > 0 )
		{
			return $q->result_array();
		}
		return false;


	}
function edit_patient_record($rec,$pr_id)
{
	$this->db->where('pr_id',$pr_id);
	$query = $this->db->update('patient_register',$rec);
	if($query){
		return 1;
	}else{
		return 0;
	}
}
	// get user
	function get_user_by_id($id)
	{
		$this->db->where('id', $id);
    $query = $this->db->get('user');
		return $query->result();
	}

	function get_s_no($id)
	{
		$auto=$this->db->query("Select max(pat_no) as s from patient_register where rhc_id= '" .$id."'");
	 return $auto->result_array();
	}

	// insert
	/*function insert_user($data)
    {
		return $this->db->insert('user', $data);
	}*/
	function insert_user($data)
		{
			$this->db->trans_start();
		 $this->db->insert('patient_register',$data);
		 $id = $this->db->insert_id();
		 $this->db->trans_complete();
		 $auto=$this->db->query("Select pat_no from patient_register where pr_id= '" .$id."'");
 	 	return $auto->result_array();


	}
	function insert_lab_record($data)
	 {
		 $this->db->trans_start();
		 $sql=$this->db->insert('lab_patients',$data);
		  $id = $this->db->insert_id();
		 $this->db->trans_complete();
		 $auto=$this->db->query("Select pat_id from lab_patients where pat_id= '" .$id."'");
 	 	return $auto->result_array();
	}
	function lab_pat_record($a,$b)
		{
			$this->db->trans_start();
		 	$sql=$this->db->query("insert into lab_patient_record(lab_reg_id,lab_tests) values('".$a."','".$b."')");
			$this->db->trans_complete();
		 if($sql){
			 return 1;
		 }else{
			 return 0;
		 }
	 }

	function insert_record($data)
		{
			$this->db->trans_start();
		 	$sql=$this->db->insert('patient_record',$data);
			 $id = $this->db->insert_id();
			$this->db->trans_complete();
		 if($sql){
			 return $id;
		 }else{
			 return 0;
		 }
	 }

	 function insert_ref_record($data)
 		{
 			$this->db->trans_start();
 		 	$sql=$this->db->insert('referred',$data);
 			 $id = $this->db->insert_id();
 			$this->db->trans_complete();
 		 if($sql){
 			 return 1;
 		 }else{
 			 return 0;
 		 }
 	 }



	 function update_drug_qty($d,$q,$p){
		 $this->db->trans_start();
		 $sql=$this->db->query("update all_drugs set  quantity=quantity-'".$q."' where phc_code='".$p."' and drug_id='".$d."'");

		 $this->db->trans_complete();
		if($sql){
			return 1;
		}else{
			return 0;
		}

	 }


	function get_phc()
	{
		$q=$this->db->query("Select * from phc ");

		if( $q->num_rows() > 0 )
		{
			return $q->result();
		}
		return false;
	}

	function get_req_phc()
	{
		$q=$this->db->query("Select * from drugs_history h,phc p where p.phc_code=h.phc_code and status=1 group by h.phc_code");

		if( $q->num_rows() > 0 )
		{
			return $q->result();
		}
		return false;
	}

	function get_phc_by_id($data)
	{
		$q=$this->db->query("Select * from phc where phc_code='".$data."'");

		if( $q->num_rows() > 0 )
		{
			return $q->result();
		}
		return false;
	}

	function get_drug()
	{
		$q=$this->db->query("Select * from all_drugs");

		if( $q->num_rows() > 0 )
		{
			return $q->result();
		}
		return false;


	}

}?>
