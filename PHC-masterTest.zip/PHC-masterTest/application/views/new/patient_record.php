<!DOCTYPE html>
<html>


          <?php
              require('side_menu.html');
          ?>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Out Patient Record
            <small>Cash Sheet of the Patient</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="box box-primary" style="background:#A2C6D7">
            <?php if($stock == 0) { ?>

                <button type="button" class="btn btn-danger btn-md " >No Medical Treatment History</button>

            <?php
            }else{?>
              <!-- Trigger the modal with a button -->

                <button type="button" class="btn btn-success btn-md " data-toggle="modal" data-target="#myModal">View Medical Treatment History</button>

                <!-- Modal -->
                <div class="modal fade" id="myModal" role="dialog">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h4 class="modal-title">Previous Medical Treatment Information</h4>
                      </div>
                      <div class="modal-body">
                        <?php
                            $i=0;
                            foreach ($stock as $row) {
                              ?>
                              <form action="<?php echo base_url(); ?>index.php/Add_details/update_history" method="post" name="upload_excel" enctype="multipart/form-data">
                                <a class="btn btn-primary" data-toggle="collapse" href="#multiCollapseExampless1<?php echo $i; ?>">Date:<?php echo  date("d-M-Y",strtotime($row['dt']));?><br/>Referred To:<?php foreach($ref_phc as $each){ ?><?php  if($row['ref']== $each->phc_code){ echo $each->phc_name;} ?>
                                 <?php } ?></a>
                                  <div class="collapse multi-collapse" id="multiCollapseExampless1<?php echo $i; ?>">
                                    <div class="card card-body">
                                      <table id="exampless1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                        <tbody>
                                          <tr>
                                              <th>Date</th>
                                              <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>
                                          </tr>
                                          <tr>
                                              <th>Patient ID</th>
                                              <td>
                                                <input type="hidden" name="pat_id" value="<?php echo $row['pat_id']; ?>">
                                                <?php echo $row['pat_no']; ?>
                                              </td>
                                          </tr>
                                          <tr>
                                              <th>Patient Name</th>
                                              <td><?php echo $row['pat_name']; ?></td>
                                          </tr>
                                          <!--   <th>Age</th>
                                          a<th>Sex</th>-->
                                          <tr>
                                            <th>Treatment Type</th>
                                            <td>
                                              <p class="break-word"><?php echo $row['visit_type']; ?></p>

                                            </td>
                                          </tr>
                                          <tr>
                                            <th>Complaints</th>
                                            <td>
                                              <textarea class="form-control"  name="compl" rows="3" placeholder="Enter Complaints..." ><?php echo $row['compl']; ?></textarea>

                                            </td>
                                          </tr>
                                          <tr>
                                            <th>Findings</th>
                                            <td>
                                              <textarea class="form-control"  name="find" rows="3" placeholder="Enter Findings..." ><?php echo $row['find']; ?></textarea>

                                            </td>
                                          </tr>
                                          <tr>
                                            <th>Diagonosis</th>
                                              <td>
                                                <textarea class="form-control"  name="diag" rows="3" placeholder="Enter Diagonosis..." ><?php echo $row['diag']; ?></textarea>

                                          </td>
                                          </tr>
                                          <tr>
                                            <th>Investigation</th>
                                            <td>
                                              <textarea class="form-control"  name="invest" rows="3" placeholder="Enter Investigation..." ><?php echo $row['invest']; ?></textarea>
                                        </td>
                                          </tr>
                                          <tr>
                                            <th>Treatment</th>
                                            <td>
                                                <textarea class="form-control"  name="treat" rows="3" placeholder="Enter Treatment..." ><?php echo $row['treat']; ?></textarea>

                                            </td>
                                          </tr>
                                          <tr>
                                            <th>Referred To</th>
                                            <td><p class="break-word"><?php foreach($ref_phc as $each){ ?>
                                                 <?php  if($row['ref']== $each->phc_code){ echo $each->phc_name;} ?>
                                             <?php } ?></p></td>
                                          </tr>
                                          <tr>
                                            <th>Prescription</th>    <td><p class="break-word"><?php echo str_replace(',',',<br/>',$row['drug']); ?></p></td>
                                          </tr>
                                          <tr>
                                            <th>Update</th>
                                            <td>  <div class="box-footer" >
                                                      <input type="submit" value="Submit" name="submit"  class="btn btn-warning">
                                              </div>
                                            </td>
                                          </tr>
                                        <!--   <tr>
                                        <td><?php echo $row['age']; ?></td>
                                        <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
                                      </tr>-->
                                    </tbody>
                                    </table>
                                  </div>
                                </div>
                              </form>
                            <br/>
                            <?php
                            $i++;
                            }?>

                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </div>
                </div>
                <?php
                  }
                ?>
                <?php if($stockd == 0) { ?>

                    <button type="button" class="btn btn-danger btn-md " >No Dental Treatment History</button>
                  <?php
                }else{?>

                  <button type="button" class="btn btn-success btn-md " data-toggle="modal" data-target="#myModals">View Dental Treatment History</button>

                <div class="modal fade" id="myModals" role="dialog">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h4 class="modal-title">Previous Dental Treatment Information</h4>
                      </div>
                      <div class="modal-body">
                        <?php
                            $i=0;
                            foreach ($stockd as $row) {
                              ?>
                              <form action="<?php echo base_url(); ?>index.php/Add_details/update_history" method="post" name="upload_excel" enctype="multipart/form-data">
                                <a class="btn btn-primary" data-toggle="collapse" href="#multiCollapseExampless2<?php echo $i; ?>">Date:<?php echo  date("d-M-Y",strtotime($row['dt']));?><br/>Referred To:<?php foreach($ref_phc as $each){ ?><?php  if($row['ref']== $each->phc_code){ echo $each->phc_name;} ?>
                                 <?php } ?></a>
                                  <div class="collapse multi-collapse" id="multiCollapseExampless2<?php echo $i; ?>">
                                    <div class="card card-body">
                                      <table id="exampless2" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                        <tbody>
                                          <tr>
                                              <th>Date</th>
                                              <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>
                                          </tr>
                                          <tr>
                                              <th>Patient ID</th>
                                              <td>
                                                <input type="hidden" name="pat_id" value="<?php echo $row['pat_id']; ?>">
                                                <?php echo $row['pat_no']; ?>
                                              </td>
                                          </tr>
                                          <tr>
                                              <th>Patient Name</th>
                                              <td><?php echo $row['pat_name']; ?></td>
                                          </tr>
                                          <!--   <th>Age</th>
                                          a<th>Sex</th>-->
                                          <tr>
                                            <th>Treatment Type</th>
                                            <td>
                                              <p class="break-word"><?php echo $row['visit_type']; ?></p>

                                            </td>
                                          </tr>
                                          <tr>
                                            <th>Complaints</th>
                                            <td>

                                              <textarea class="form-control"  name="compl" rows="3" placeholder="Enter Complaints..." ><?php echo $row['compl']; ?></textarea>

                                            </td>
                                          </tr>
                                          <tr>
                                            <th>Findings</th>
                                            <td>
                                              <textarea class="form-control"  name="find" rows="3" placeholder="Enter Findings..." ><?php echo $row['find']; ?></textarea>

                                            </td>
                                          </tr>
                                          <tr>
                                            <th>Diagonosis</th>
                                              <td>
                                                <textarea class="form-control"  name="diag" rows="3" placeholder="Enter Diagonosis..." ><?php echo $row['diag']; ?></textarea>

                                          </td>
                                          </tr>
                                          <tr>
                                            <th>Investigation</th>
                                            <td>
                                              <textarea class="form-control"  name="invest" rows="3" placeholder="Enter Investigation..." ><?php echo $row['invest']; ?></textarea>
                                        </td>
                                          </tr>
                                          <tr>
                                            <th>Treatment</th>
                                            <td>
                                                <textarea class="form-control"  name="treat" rows="3" placeholder="Enter Treatment..." ><?php echo $row['treat']; ?></textarea>

                                            </td>
                                          </tr>
                                          <tr>
                                            <th>Referred To</th>
                                            <td><p class="break-word"><?php foreach($ref_phc as $each){ ?>
                                                 <?php  if($row['ref']== $each->phc_code){ echo $each->phc_name;} ?>
                                             <?php } ?></p></td>
                                          </tr>
                                          <tr>
                                            <th>Prescription</th>    <td><p class="break-word"><?php echo str_replace(',',',<br/>',$row['drug']); ?></p></td>
                                          </tr>
                                          <tr>
                                            <th>Update</th>
                                            <td>  <div class="box-footer" >
                                                      <input type="submit" value="Submit" name="submit"  class="btn btn-warning">
                                              </div>
                                            </td>
                                          </tr>
                                        <!--   <tr>
                                        <td><?php echo $row['age']; ?></td>
                                        <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
                                      </tr>-->
                                    </tbody>
                                    </table>
                                  </div>
                                </div>
                              </form>
                            <br/>
                            <?php
                            $i++;
                            }?>

                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </div>
                </div>
                <?php
                  }
                ?>

                <?php if($stockde == 0) { ?>

                      <button type="button" class="btn btn-danger btn-md " >No Psychiatric Treatment History</button>
                <?php
                  }else{?>

                      <button type="button" class="btn btn-success btn-md " data-toggle="modal" data-target="#myModalss">View Psychiatric Treatment History</button>

                        <div class="modal fade" id="myModalss" role="dialog">
                            <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                          <h4 class="modal-title">Previous Psychiatric Treatment Information</h4>
                                      </div>
                                      <div class="modal-body">
                                        <?php
                                        $i=0;
                                        foreach ($stockde as $row) {
                                        ?>
                                        <form action="<?php echo base_url(); ?>index.php/Add_details/update_history" method="post" name="upload_excel" enctype="multipart/form-data">
                                          <a class="btn btn-primary" data-toggle="collapse" href="#multiCollapseExampless<?php echo $i; ?>" role="button" aria-expanded="false" aria-controls="multiCollapseExample<?php echo $i; ?>">Date:<?php echo  date("d-M-Y",strtotime($row['dt']));?><br/>Referred To:<?php foreach($ref_phc as $each){ ?><?php  if($row['ref']== $each->phc_code){ echo $each->phc_name;} ?>
                                           <?php } ?></a>
                                            <div class="collapse multi-collapse" id="multiCollapseExampless<?php echo $i; ?>">
                                              <div class="card card-body">
                                                <table id="exampless" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                  <tbody>
                                                    <tr>
                                                        <th>Date</th>
                                                        <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Patient ID</th>
                                                        <td>
                                                          <input type="hidden" name="pat_id" value="<?php echo $row['pat_id']; ?>">
                                                          <?php echo $row['pat_no']; ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th>Patient Name</th>
                                                        <td><?php echo $row['pat_name']; ?></td>
                                                    </tr>
                                                    <!--   <th>Age</th>
                                                    a<th>Sex</th>-->
                                                    <tr>
                                                      <th>Treatment Type</th>
                                                      <td>
                                                        <p class="break-word"><?php echo $row['visit_type']; ?></p>

                                                      </td>
                                                    </tr>
                                                    <tr>
                                                      <th>Complaints</th>
                                                      <td>
                                                        <textarea class="form-control"  name="compl" rows="3" placeholder="Enter Complaints..." ><?php echo $row['compl']; ?></textarea>

                                                      </td>
                                                    </tr>
                                                    <tr>
                                                      <th>Findings</th>
                                                      <td>
                                                        <textarea class="form-control"  name="find" rows="3" placeholder="Enter Findings..." ><?php echo $row['find']; ?></textarea>

                                                      </td>
                                                    </tr>
                                                    <tr>
                                                      <th>Diagonosis</th>
                                                        <td>
                                                          <textarea class="form-control"  name="diag" rows="3" placeholder="Enter Diagonosis..." ><?php echo $row['diag']; ?></textarea>

                                                    </td>
                                                    </tr>
                                                    <tr>
                                                      <th>Investigation</th>
                                                      <td>
                                                        <textarea class="form-control"  name="invest" rows="3" placeholder="Enter Investigation..." ><?php echo $row['invest']; ?></textarea>
                                                  </td>
                                                    </tr>
                                                    <tr>
                                                      <th>Treatment</th>
                                                      <td>
                                                          <textarea class="form-control"  name="treat" rows="3" placeholder="Enter Treatment..." ><?php echo $row['treat']; ?></textarea>

                                                      </td>
                                                    </tr>
                                                    <tr>
                                                      <th>Referred To</th>
                                                      <td><p class="break-word"><?php foreach($ref_phc as $each){ ?>
                                                           <?php  if($row['ref']== $each->phc_code){ echo $each->phc_name;} ?>
                                                       <?php } ?></p></td>
                                                    </tr>
                                                    <tr>
                                                      <th>Prescription</th>    <td><p class="break-word"><?php echo str_replace(',',',<br/>',$row['drug']); ?></p></td>
                                                    </tr>
                                                    <tr>
                                                      <th>Update</th>
                                                      <td>  <div class="box-footer" >
                                                                <input type="submit" value="Submit" name="submit"  class="btn btn-warning">
                                                        </div>
                                                      </td>
                                                    </tr>
                                                  <!--   <tr>
                                                  <td><?php echo $row['age']; ?></td>
                                                  <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
                                                </tr>-->
                                              </tbody>
                                              </table>
                                            </div>
                                          </div>
                                        </form>
                                          <br/>
                                          <?php

                                          $i++;
                                          }?>

                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <?php
                                  }
                                ?>


              <!-- form start -->
                <?php echo form_open('Outreg/Add_precord');?>
                <div class="box-body">
                  <input id="prh" type="text" value="<?php echo $phc_code;?>" name="prh" hidden="">
                    <?php
                      foreach ($pat_name as $row) {
                      ?>

                      <div class="col-md-6">
                        <div class="form-group">
                          <label>Patient ID<span style="color:red">&nbsp*</span></label>
                          <input readonly type="text" class="form-control" value="<?php echo $row['pat_no'];?>" name="pat_no" placeholder="Enter Patient's Name" required="">
                        </div>

                        <div class="form-group">
                          <label>Patient Name<span style="color:red">&nbsp*</span></label>
                          <input readonly type="text" class="form-control" value="<?php echo $row['pat_name'];?>" name="pat_name" placeholder="Enter Patient's Name" required="">
                        </div>
                        <div class="form-group">
                          <label>Patient Age<span style="color:red">&nbsp*</span></label>
                          <input type="text" class="form-control" value="<?php echo $row['age'];?>" name="pat_age" placeholder="Enter Patient's Age" required="">
                        </div>

                        <div class="form-group">
                            <label>Diagonosis</label>
                            <textarea class="form-control"  name="diag" rows="3" placeholder="Enter Diagonosis..." ></textarea>
                        </div>
                        <div class="form-group">
                            <label>Investigation<span style="color:red">&nbsp*</span></label>
                            <textarea class="form-control"  name="invest" rows="3" placeholder="Enter Investigation..." ></textarea>

                        </div>
                        <div class="form-group">
                            <label>Referred To<span style="color:red">&nbsp*</span></label>
                        <!---    <textarea class="form-control"  name="ref" rows="3" placeholder="Enter Reference..." required=""></textarea>
                        -->

                        <select name="ref" class="form-control" required>
                          <option value="">Select PHC</option>
                            <?php foreach($ref_phc as $each){ ?>
                                 <option value="<?php echo $each->phc_code; ?>"><?php echo $each->phc_name; ?></option>
                             <?php } ?>
                        </select>
                        </div>
                        <div class="form-group">
                            <label>Treatment Type<span style="color:red">&nbsp*</span></label>
                            <select name="trt_type" class="form-control" required>
                              <option value="">Treatment Type</option>
                                <option value="Psychiatric Treatment">Psychiatric Treatment</option>
                                <option value="Medical Treatment">Medical Treatment</option>
                                <option value="Dental Treatment">Dental Treatment</option>

                            </select>
                        </div>
                        <div class="form-group">

                          <input  readonly type="hidden" class="form-control" value="<?php if(strtotime($row['date']) < strtotime(date("Y-m-d")))
                          { echo "0";}else{echo "1";}?>" name="patV_type" placeholder="Enter Patient's Name" required="">
                        </div>
                      </div>
                      <div class="col-md-6">

                        <div class="form-group">
                          <label>Patient's Father Name<span style="color:red">&nbsp*</span></label>
                          <input readonly type="text" class="form-control" value="<?php echo $row['pat_father'];?>" name="pat_fn" placeholder="Enter Patient's Name" required="">
                        </div>

                      <?php
                      }

                     ?>
                     <div class="form-group">
                       <label>PHC Name<span style="color:red">&nbsp*</span></label>
                       <select class="form-control" name="phc">
                         <?php foreach($phc as $each){ ?>
                              <option value="<?php echo $each->phc_code; ?>"><?php echo $each->phc_name; ?></option>';
                          <?php } ?>
                       </select>
                     </div>
                     <div class="form-group">
                       <label>Patient Gender<span style="color:red">&nbsp*</span></label>
                       <input readonly type="text" class="form-control" value="<?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?>" name="pat_sex" placeholder="Enter Patient's Name" required="">
                     </div>
                    <div class="form-group">
                        <label>Complaints</label>
                        <textarea class="form-control"  name="compl" rows="3" placeholder="Enter Complaints..." ></textarea>
                    </div>
                    <div class="form-group">
                        <label>Findings</label>
                        <textarea class="form-control"  name="Findings" rows="3" placeholder="Enter Findings..." ></textarea>
                    </div>
                    <div class="form-group">
                        <label>Treatment</label>
                        <textarea class="form-control"  name="treat" rows="3" placeholder="Enter Treatment..." ></textarea>
                    </div>
                    </div>

                    <div class="col-md-12">
                      <?php if(($row['age'] >= 18)&&($row['sex']==2)){?>
                      <div class="alert alert-danger alert-dismissable fade in">
                           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                          <strong>Note..!&nbsp &nbsp</strong> Please confirm whether Patient is Pregnant and provide suitable medicines..
                      </div>
                      <?php }?>
                        <label>Medicine Prescription</label>
                        <input type="radio" id="chkYes" name="nrkp" value="1" class="flat-red" onclick="ShowHideDiv()" required><label>Yes</label>&nbsp&nbsp&nbsp
                        <input type="radio" id="chkNo" name="nrkp"  value ="0" class="flat-red" onclick="ShowHideDiv()" required><label>No</label>
                        <div id="set1" style="display:none">
                          <div class="col-md-12">
                              <button type="button" id="set" class="btn btn-danger btn-lg" data-toggle="modal" data-target="#myModal1">Choose Drugs</button>

                          </div>
  								      </div>
                    </div>

                    <div class="col-md-12">
                      <input type="submit" id="sub" value="submit" name="submit"  class="btn btn-primary pull-right">
                      <div class="modal fade" id="myModal1" role="dialog">
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title"><center style="color:red">Choose Drugs</center></h4>
                            </div>
                            <div class="modal-body">
                          <table id="drugs_table" class="table table-striped" style="width:100% ;">
                             <tr id="row1" class="">
                               <tr>
                                 <th>Drug Name</th>
                                 <th>Quantity</th>
                               </tr>
                               <td>
                                  <div class="form-group">
                                    <input autocomplete="off" type="text" id="id" value="" class="form-control drug_name" name="drug_name[]" placeholder="Enter Drug Name.." >
                                    <div id="suggesstion-box"></div>
                                  </div>

                                  &nbsp<input type="text" id="di1" name="drug_id[]" hidden="">
                                  &nbsp<input type="text" id="di2"  name="drug_qty[]" hidden="">
                              </td>
                              <td>
                                <div class="form-group ">

                                  <input autocomplete="off"  type="number" min="1" id="id1" class="form-control" name="qunt[]" placeholder="Enter Quantity..." >
                                  <p id="q"></p><p id="m"></p>
                                </div>
                              </td>

                              <td>
                                <div class="form-group ">

                                  <button  class="btn-info btn-sm" type="button"   onclick="add_row();"  id="add">
                                     <span class="glyphicon glyphicon-plus"></span>
                                  </button>
                                </div>
                              </td>
                              <td>

                              </td>

                            </tr>
                            </table>
                          </div>
                           <div class="modal-footer">
                             <button type="button" class="btn btn-default" data-dismiss="modal">Minimize</button>
                              <input type="submit" id="sub" value="submit" name="submit"  class="btn btn-primary pull-right">
                           </div>
                         </div>
                       </div>
                      </div>
                    </div>
                </div><!-- /.box-body -->

            <?php  form_close(); ?>
            </div><!-- /.box -->
          </div>




        </section><!-- /.content -->
      </div><!-- /.content-wrapper
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.3.0
        </div>
        <strong>Copyright &copy; 2017 .</strong> All rights reserved.
      </footer>-->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->

      </div><!-- ./wrapper -->

      <!-- jQuery 2.1.4 -->

      <script src="<?php echo base_url();?>plugins/jQuery/jQuery-2.1.4.min.js"></script>
      <!-- jQuery UI 1.11.4 -->
      <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />-->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.3.1/css/buttons.dataTables.min.css" />

      <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.print.min.js"></script>
      <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
      <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

      <script type="text/javascript">
      function add_row()
       {
          $rowno=$("#drugs_table tr").length;
          $rowno=$rowno+1;
           $a = $('#id').val();
          $b = $('#id1').val();
          $c = $('#di1').val();
          $d = $('#di2').val();
          $("#q").html("<span style=color:blue>Available Quantity</span>&nbsp:&nbsp<span style=color:red></span>&nbsp<span style=color:black></span>");

          //if($b>$d){
          //  alert("Entered Quantity should be less than Available Quantity");
          //  $("#id1").css("border","3px solid red");
        //  }else{
            if(($a!="") && ($b!="")){
            $("#drugs_table tr:last").before('<tr id="row'+$rowno+'"><td><div class="form-group"><input type="text" class="form-control" value="'+ $a +'"  name="drug_name[]" placeholder="Enter Drug Name"  readonly></div><input type="text" id="di1" value="'+$c+'" hidden name="drug_id[]" ><input type="number" id="di2" value="'+$d+'" name="drug_qty[]" hidden=""></td><td><div class="form-group"><input type="text" value="'+$b+'" name="qunt[]" class="form-control" placeholder="Enter Quantity" readonly></div></td><td><div class="form-group"><img src="<?php echo base_url();?>img/no.png" id="delete"  onclick="delete_row('+$rowno+')"></div></td></tr>');
            $("#id").css("border","2px solid black");
            $("#id1").css("border","2px solid black ");
            $a = $('#id').val("");
            $b = $('#id1').val("");
            $c = $('#id1').val("");

          }else if(($a=="") && ($b="")){
            $("#id").css("border","3px solid red");
            $("#id1").css("border","3px solid red");
          }else if($a==""){
            $("#id").css("border","3px solid red");
          }else if($b==""){
            $("#id1").css("border","3px solid red");
          }else if(($a=="")&&($b!="")){
            $("#id").css("border","3px solid red");
       }else if(($a!="")&&($b=="")){
         $("#id1").css("border","3px solid red");
       }
       }

       function delete_row(rowno)
       {

        $("#row"+rowno).remove();
      }


       function check_phc()
       {
        var name=document.getElementById( "phc_code" ).value;

        if(name)
        {
         $.ajax({
         type: 'post',
         url: "<?php echo site_url('Add_details/index1');?>",
         data: {
          phc_id:name,
         },
         success: function (response) {
          $( '#code_status' ).html(response);
            if(response=="OK")
            {
             return true;
            }
            else
            {
             return false;D
            }
           }
         });
        }
       }

      function check_doc()
      {
       var name=document.getElementById( "doc_id" ).value;

       if(name)
       {
        $.ajax({
        type: 'post',
        url: "<?php echo site_url('Add_details/index2');?>",
        data: {
         doc_id:name,
        },
        success: function (response) {
         $( '#code_status' ).html(response);
           if(response=="OK")
           {
            return true;
           }
           else
           {
            return false;
           }
          }
        });
       }
      }

      function check_drug()
      {
       var name=document.querySelector('.drug_name').value;
        var phc=document.getElementById('phc_code').value;

       if(name)
       {
        $.ajax({
        type: 'post',
        url: "<?php echo site_url('Add_details/index3');?>",
        data: {
         drug_name:name,
         phc_code:phc
        },
        success: function (response) {
         $( '#code_status' ).html(response);
           if(response=="OK")
           {

            return true;
           }
           else
           {

            return false;
           }
          }
        });
       }
      }

      $( function() {
         $( "#dat1" ).datepicker({
           setDate: new Date(),
           changeMonth: true,
           changeYear: true,
             format:'yyyy-mm-dd'
         });
       } );
      /*-------------------*/
       $(document).ready(function(){

        $("#id").keyup(function(){
           var m=$(this).val();
           var n=$("#prh").val();
          $.ajax({
          type: "POST",
          url: "<?php echo site_url('Add_details/index4');?>",
          data:{
            keyword:m,
            rh:n,
            },

          success: function(data){
            $("#suggesstion-box").show();
            $("#suggesstion-box").html(data);
            $("#id").css("background","#FFF");
          }
          });
        });
       });

       function selectDrug(val,val1,val2,val3) {
       $("#id").val(val);
        $("#di1").val(val1);
        $("#di2").val(val2);
        if(val2==0){
          alert("Drug Quantity is Empty");
          $("#id1").hide();
          $("#add").hide();
          $("#sub").hide();

        }else{
            $("#id1").attr("max", val2);
            $("#id1").show();
            $("#add").show();
            $("#sub").show();
            $("#q").html("<span style=color:blue>Available Quantity</span>&nbsp:&nbsp<span style=color:red>"+val2+"</span>&nbsp<span style=color:black>"+val3+"</span>");

        }

       $("#suggesstion-box").hide();
       }
      /*----------------*/



        //Start of the data table
       $(document).ready( function () {
         var table = $('#example').DataTable({
       	"dom": '<"toolbar">frtBpli',
       "scrollX": true
         });
       $("div.toolbar").html('<input id="date_range" type="text" class="col-md-3" placeholder="Pick Date">');
       //END of the data table

       // Date range script - Start of the sscript
       $("#date_range").daterangepicker({
       	autoUpdateInput: false,
       	locale: {
       		"cancelLabel": "Clear",
               }
       });

       $("#date_range").on('apply.daterangepicker', function(ev, picker) {
             $(this).val(picker.startDate.format('YYYY-MM-DD') + ' to ' + picker.endDate.format('YYYY-MM-DD'));
       	  table.draw();
       });

       $("#date_range").on('cancel.daterangepicker', function(ev, picker) {
             $(this).val('');
       	  table.draw();
       });
       // Date range script - END of the script

       $.fn.dataTableExt.afnFiltering.push(
       function( oSettings, aData, iDataIndex ) {

       	var grab_daterange = $("#date_range").val();
       	var give_results_daterange = grab_daterange.split(" to ");
           var filterstart = give_results_daterange[0];
           var filterend = give_results_daterange[1];
           var iStartDateCol = 0; //using column 2 in this instance
           var iEndDateCol = 0;
           var tabledatestart = aData[iStartDateCol];
           var tabledateend= aData[iEndDateCol];

           if ( !filterstart && !filterend )
           {
               return true;
           }
           else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isBefore(tabledatestart)) && filterend === "")
           {
               return true;
           }
           else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isAfter(tabledatestart)) && filterstart === "")
           {
               return true;
           }
           else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isBefore(tabledatestart)) && (moment(filterend).isSame(tabledateend) || moment(filterend).isAfter(tabledateend)))
           {
               return true;
           }
           return false;
       }
       );

       //End of the datable
        });
      /*-------------------*/
      /*to drug stock by date*/

      /*----------------*/
      $(document).ready(function (){
        $.ajax({
        type: 'post',
        url: "<?php echo site_url('Fetch/notification');?>",

        success: function (response) {
          $( '#notification_count').html(response);
           if(response=="OK")
           {
            return true;
           }
           else
           {
            return false;
           }
          }
        });

      });

      $(document).ready(function (){
         var phc = $('#21').val();

        $.ajax({
        type: 'post',
        url: "<?php echo site_url('Fetch/notification1');?>",
        data:{
          p:phc,
        },
        success: function (response) {
          $( '#notification_count1').html(response);
           if(response=="OK")
           {
            return true;
           }
           else
           {
            return false;
           }
          }
        });

      });
      /****************/
      $(document).ready(function(){
          $('#id').bind("cut copy paste",function(e) {
            e.preventDefault();
            alert("Cut or Copy or Paste is not allowed..!!!");
          });
        });
        /************/
        /************/
    $('#chkYes').change(function () {

      if(this.checked) {
          $('#set1').show();
        $('#set').show();
        $('#id').prop('required', true);
        $('#id1').prop('required', true);
    } else {
        $('#set').hide();
        $('#id').prop('required', false);
        $('#id1').prop('required', false);

    }
  });
  $('#chkNo').change(function () {

    if(this.checked) {
      $('#set').hide();
      $('#id').prop('required', false);
      $('#id1').prop('required', false);
  } else {
      $('#set').show();
      $('#id').prop('required', true);
      $('#id1').prop('required', true);

  }
});
      </script>

      <!-- Bootstrap 3.3.5-->
      <script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
      <!-- Morris.js charts -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <!--  <script src="<?php echo base_url();?>plugins/morris/morris.min.js"></script> -->
      <!-- Sparkline -->
      <script src="<?php echo base_url();?>plugins/sparkline/jquery.sparkline.min.js"></script>
      <!-- jvectormap -->
      <script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
      <script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
      <!-- jQuery Knob Chart -->
      <script src="<?php echo base_url();?>plugins/knob/jquery.knob.js"></script>
      <!-- daterangepicker -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
      <script src="<?php echo base_url();?>plugins/daterangepicker/daterangepicker.js"></script>
      <!-- datepicker -->
      <script src="<?php echo base_url();?>plugins/datepicker/bootstrap-datepicker.js"></script>
      <!-- Bootstrap WYSIHTML5 -->
      <script src="<?php echo base_url();?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
      <!-- Slimscroll -->
      <script src="<?php echo base_url();?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url();?>plugins/fastclick/fastclick.min.js"></script>
      <!-- AdminLTE App -->
      <script src="<?php echo base_url();?>dist/js/app.min.js"></script>
      <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!--  <script src="<?php echo base_url();?>dist/js/pages/dashboard.js"></script> -->
      <!-- AdminLTE for demo purposes -->
      <script src="<?php echo base_url();?>dist/js/demo.js"></script>

  <style>
  .frmSearch {border: 1px solid #a8d4b1;background-color:#A2C6D7;margin: 2px 0px;padding:5px;border-radius:4px;}
  #drug-list{float:left;list-style:none;margin-top:-3px;padding:0;width:190px;position: absolute;}
  #drug-list li{padding: 10px; background: white; border-bottom: #bbb9b9 1px solid;}
  #drug-list li:hover{background:yellow;cursor: pointer;}
  #search-box{padding: 10px;border: #a8d4b1 1px solid;border-radius:4px;}
  .modal-dialog {
    width: 100%;
    height: 100%;
    padding: 0;
  }

  .break-word {
  width: 13em;
/*  background: lime;*/
  overflow-wrap: break-word;
}

  </style>
  </body>

</html>
