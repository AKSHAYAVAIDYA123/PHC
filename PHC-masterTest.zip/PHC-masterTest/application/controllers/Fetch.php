<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fetch extends CI_Controller {


	 public function __construct() {
     parent::__construct();
		 $this->load->database();
		 $this->load->model(array('Add_model','Fetch_model','User_model','Update_model','Csv_model'));
		 $this->load->library('session');
			$this->load->helper('url');
   }

	 public function index(){
		 if($this->session->userdata('Login')){
        $this->load->model('User_model');
				$this->load->model('Fetch_model');
  			$session=$this->session->userdata('Login');
  			$user['user_id']=$session['id'];
  			$user['email']=$session['email'];
  			$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$result=$this->User_model->get_phc_by_id($user['phc_code']);
				$user['phc']=$result;
				$resultq=$this->User_model->get_phc();
				$user['ref_phc']=$resultq;
				$res=$this->User_model->get_drug();
				$user['drug_name']=$res;
				$user['title']="Patient Record Details";
        $patid= $this->input->post('pat_id');

				$result=$this->Fetch_model->get_pat_history($user['phc_code'],$patid);
				if($result==0){
					$user['stock']=0;
				}else{
					$user['stock']=$result;
				}

				$resultd=$this->Fetch_model->get_pat_history_dent($user['phc_code'],$patid);
				if($resultd==0){
					$user['stockd']=0;
				}else{
					$user['stockd']=$resultd;
				}
				$resultde=$this->Fetch_model->get_pat_history_psy($user['phc_code'],$patid);
				if($resultde==0){
					$user['stockde']=0;
				}else{
					$user['stockde']=$resultde;
				}
					/*warning*/
				$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
				$user['warning']=$warn;
				$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
				$user['all_warning']=$a_warn;
  			$result=$this->Fetch_model->get_pat($patid);
				if($result!=0){
          $user['pat_name']=$result;
					$this->load->view('new/patient_record',$user);
				}else{
						?><script>alert("Invalid Patient ID");</script><?php
						redirect('Myhome/pat_hist','refresh');
				}
  		}else{
  			redirect('/', 'refresh');
  		}
   }

	 public function edit_index(){
		if($this->session->userdata('Login')){
				$this->load->model('User_model');
			 $this->load->model('Fetch_model');
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
			 $result=$this->User_model->get_phc_by_id($user['phc_code']);
			 $user['phc']=$result;
			 $resultq=$this->User_model->get_phc();
			 $user['ref_phc']=$resultq;
			 $res=$this->User_model->get_drug();
			 $user['drug_name']=$res;
			 $user['title']="Patient Record Details";
				$patid= $this->input->post('pat_id');
			 $result=$this->Fetch_model->get_pat_history($user['phc_code'],$patid);
			 if($result==0){
				 $user['stock']=0;
			 }else{
				 $user['stock']=$result;
			 }
				 /*warning*/
			 $warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
			 $user['warning']=$warn;
			 $a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
			 $user['all_warning']=$a_warn;
			 $result=$this->Fetch_model->get_pat($patid);
			 if($result!=0){
					$user['pat_name']=$result;
				 $this->load->view('new/edit_patient_record',$user);
			 }else{
					 ?><script>alert("Invalid Patient ID");</script><?php
					 redirect('Myhome/pat_hist','refresh');
			 }
		 }else{
			 redirect('/', 'refresh');
		 }
	 }

	 public function index2(){
  	if($this->session->userdata('Login')){
        	$this->load->model('User_model');
				 	$this->load->model('Fetch_model');
  				$session=$this->session->userdata('Login');
  				$user['user_id']=$session['id'];
  				$user['email']=$session['email'];
  				$user['name']=$session['name'];
					$user['role']=$session['role'];
					$user['phc_code']=$session['phc_code'];
					$result=$this->User_model->get_phc_by_id($user['phc_code']);
					$user['phc']=$result;

					/*$res=$this->User_model->get_drug();
					$user['drug_name']=$res;*/

					$user['title']="Lab Patient Record Details";
          $patid= $this->input->post('pat_id');

					/*$result=$this->Fetch_model->get_pat_history($user['phc_code'],$patid);
					if($result==0){
						$user['stock']=0;

					}else{
						$user['stock']=$result;

					}*/
					$phc_name=$this->Fetch_model->get_phc_name($user['phc_code']);
					$user['phc_name']=$phc_name;

					$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
					$user['warning']=$warn;
					$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
					$user['all_warning']=$a_warn;
					$lab_types=$this->Fetch_model->get_all_test_types1($user['phc_code']);
					$user['lab_types']=$lab_types;
					$lab_tests=$this->Fetch_model->get_all_lab_test_blood();//$user['phc_code']);
					$user['lab_test']=$lab_tests;
					$lab_tests=$this->Fetch_model->get_all_lab_test_urine();//$user['phc_code']);
					$user['lab_tests']=$lab_tests;


  				$result=$this->Fetch_model->get_ref_pat($patid);
					if($result!=0){
          	$user['lab_pat_name']=$result;
						$this->load->view('new/lab_comp',$user);
					}else{
						?><script>alert("Invalid Patient ID");</script><?php
						redirect('Myhome/pat_hist','refresh');
					}
  		}else{
  			redirect('/', 'refresh');
  		}
   }
	 public function fun($a)
	 {
		 $lab_tests=$this->Fetch_model->get_all_lab_test_tests($a);//$user['phc_code']);
		 if($lab_tests){
		 	return $lab_tests;
	 	}else{
			return 0;
		}
	 }

	 public function index3(){
		 if($this->session->userdata('Login')){
         	$this->load->model('User_model');
 				 	$this->load->model('Fetch_model');
   				$session=$this->session->userdata('Login');
   				$user['user_id']=$session['id'];
   				$user['email']=$session['email'];
   				$user['name']=$session['name'];
 					$user['role']=$session['role'];
 					$user['phc_code']=$session['phc_code'];
 					$result=$this->User_model->get_phc_by_id($user['phc_code']);
 					$user['phc']=$result;

 					/*$res=$this->User_model->get_drug();
 					$user['drug_name']=$res;*/

 					$user['title']="Lab Patient Record Details";
           $patid= $this->input->post('pat_id');

 					/*$result=$this->Fetch_model->get_pat_history($user['phc_code'],$patid);
 					if($result==0){
 						$user['stock']=0;

 					}else{
 						$user['stock']=$result;

 					}*/
 					$phc_name=$this->Fetch_model->get_phc_name($user['phc_code']);
 					$user['phc_name']=$phc_name;

 					$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
 					$user['warning']=$warn;
 					$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
 					$user['all_warning']=$a_warn;
 					$lab_types=$this->Fetch_model->get_all_test_types1($user['phc_code']);
 					$user['lab_types']=$lab_types;
 					$lab_tests=$this->Fetch_model->get_all_lab_test_blood();//$user['phc_code']);
 					$user['lab_test']=$lab_tests;
 					$lab_tests=$this->Fetch_model->get_all_lab_test_urine();//$user['phc_code']);
 					$user['lab_tests']=$lab_tests;


   				$result=$this->Fetch_model->get_ref_pat1($patid);
 					if($result!=0){
           	$user['lab_pat_name']=$result;
 						$this->load->view('new/lab_comp_new',$user);
 					}else{
 						?><script>alert("Invalid Patient ID");</script><?php
 						redirect('Myhome/pat_hist','refresh');
 					}
   		}else{
   			redirect('/', 'refresh');
   		}
	 }

	 public function fun2($a)
	 {
		 $lab_tests=$this->Fetch_model->get_all_lab_test_results($a);//$user['phc_code']);
		 if($lab_tests){
		 	return $lab_tests;
	 	}else{
			return 0;
		}
	 }








 	/*To Fetch Visitors-Graph*/
	 function getdata(){
		 if($this->session->userdata('Login')){
					 $this->load->model('User_model');
					 $this->load->model('Fetch_model');
					 $session=$this->session->userdata('Login');
					 $user['user_id']=$session['id'];
					 $user['email']=$session['email'];
					 $user['name']=$session['name'];
					 $user['role']=$session['role'];
					 $user['phc_code']=$session['phc_code'];
			    	$y= $this->input->post('p');
	  		 		$data  = $this->Fetch_model->getdata($y, $user['phc_code']);
						print_r(json_encode($data, true));
				}else{
					redirect('/', 'refresh');
				}
    }
	function labdata(){
			$y= $this->input->post('p');
			$m= $this->input->post('p1');
			$data  = $this->Fetch_model->get_labdata($y,$m);
 			print_r(json_encode($data, true));
	}
	function labdata_ref(){
			$y= $this->input->post('p');
 			$m= $this->input->post('p1');
			$data  = $this->Fetch_model->get_labdata_ref($y,$m);
			print_r(json_encode($data, true));
	}
	function labdata_ref2(){
			$y= $this->input->post('p');
 			$m= $this->input->post('p1');
 			$data  = $this->Fetch_model->get_labdata_ref2($y,$m);
 			print_r(json_encode($data, true));
	}
	function notification(){
			$data  = $this->Fetch_model->get_notif();
 			echo $data;
	}
	function admin_get_ot_ward(){
		if($this->session->userdata('Login')){
 			$this->load->model('User_model');
 			$session=$this->session->userdata('Login');
 			$user['user_id']=$session['id'];
 			$user['email']=$session['email'];
 			$user['name']=$session['name'];
 			$user['role']=$session['role'];
 			$result=$this->User_model->get_phc();
 			$user['phc']=$result;
 			$user['phc_code']=$session['phc_code'];
 			$user['title']="Drugs Out Ward Register";
			$rhc= $this->input->post('phc');
			$result=$this->Fetch_model->admin_get_otward($rhc);
			$user['stock']=$result;
			$this->load->view('new/admin_out_ward_reg',$user);
		}else{
							redirect('/', 'refresh');
					}
		}
/***********/
function back(){
	$data  = $this->Fetch_model->get_back();
		if($data){
			return 1;
		}else{
			return 0;

	}
}
				 function notification1(){
					 $y= $this->input->post('p');
	 					 $data  = $this->Fetch_model->get_notif1($y);
						 if($data!=0){
							 print_r("new");
						 }else{
							 print_r("0");
						 }

	 	       }
					 function fetch_req(){
						 $y= $this->input->post('p');
		 					 $data  = $this->Fetch_model->req_drug_admin($y);
							 $si=1;
							?>
									<table  class=" table table-striped table-bordered" style="background:#B3CDE0" cellspacing="0" width: 100%;>
										<thead style="background:#CDF400;">
											<tr>
													<th>Requested on</th>
													<th>Requested Drug Name</th>
													<th>Balance Stock</th>
													<th>Requested Qty</th>
													<th>Requested By</th>
													<th>Providing Qty</th>
											</tr>
										</thead>
										<?php	foreach ($data as $row) {?>
											<tbody>
											<tr>
						 						<td>
						 							<input type="hidden" name="rhc_id[]" class="form-control" value="<?php echo $row['phc_code']; ?>">
						 							<input type="hidden" name="hist_id[]" class="form-control" value="<?php echo $row['hist_id']; ?>"><input type="hidden" name="month[]" class="form-control" value="<?php echo $row['month_year']; ?>"><span style="color:red"><?php echo date('d-M-Y',strtotime($row['month_year']))?></span>
												</td>

						 						<td>
													<input type="hidden" name="drug_id[]" class="form-control" value="<?php echo $row['drug_id']; ?>"><?php echo $row['drug_name']; ?>
												</td>

						 						<td>
													<input type="hidden" name="cur_quantity[]" class="form-control" value="<?php echo $row['cur_quantity']; ?>"readonly><?php echo str_replace("-","",$row['cur_quantity']); ?>
												</td>

						 					<td><input type="hidden" name="req_quantity[]"  value="<?php echo $row['req_quantity']; ?>" class="form-control"><?php echo $row['req_quantity']; ?></td>
											<td><?php
													print_r($row['req_name']);
											 ?>

											</td>
											<td><input type="number" min="0" max="10000" name="rec_quantity[]"  value="<?php echo $row['req_quantity']; ?>" class="form-control" ></td>
						 				</tr>

									</tbody>
						<?php		}?>
						<tr>
							<td colspan="6"><center><input type="Submit" name="submit" value="Confirm" class="btn btn-success btn-md"></center></td>
						</tr>	</table><?php
		 	       }

					 function getpat_det(){
	 		     $y= $this->input->post('pi');

					 $data  = $this->Fetch_model->getpat_det($y);
					 foreach ($data as $row) {
				 ?>

			 		<tr>
							<td><h5><label>Patient ID &nbsp:&nbsp</label><?php echo $row['pat_no']; ?></h5></td>

							<td><label>Date of Visit</label> &nbsp:&nbsp<?php echo $row['date_fv']; ?></td>

				 </tr>

				 <tr>
					 		<td><h5><label>NRK ID &nbsp:&nbsp</label><?php echo $row['nrkid']; ?></h5></td>
							<td><h5><label>Patient Name &nbsp:&nbsp</label><?php echo $row['pat_name']; ?><h5></td>
				 </tr>
				 <tr>
							<td><h5><label>Father Name &nbsp:&nbsp</label><?php echo $row['pat_father']; ?></h5></td>
							<td><h5><label>Address &nbsp:&nbsp</label><?php echo $row['pat_addrs']; ?></h5></td>
				 </tr>
				 <tr>
							<td><h5><label>Sex &nbsp:&nbsp</label><?php if($row['sex']==1){echo "Male";}else{echo "Female";} ?></h5></td>
							<td><h5><label>Age &nbsp:&nbsp</label><?php echo $row['age']; ?></h5></td>
				</tr>
						<tr>
							<td><h5><label>Phone No &nbsp:&nbsp</label><?php echo $row['phno']; ?></h5></td>
							<td><h5><label>PHC Name &nbsp:&nbsp</label><?php echo $row['phc_name']; ?></h5></td>
 						</tr>


			 <?php
				 }
	       }

/*********************/
				 function get_incharge(){

	 	 		     $i= $this->input->post('i');
						 $data  = $this->Fetch_model->get_incharge($i);
						 foreach ($data as $row) {?>
							 <tr>
								 <td>
									 	<input type="text" name="usr_name" value="<?php echo $row['name']; ?>" class="form-control" readonly="">
									</td>
								 <td>
									 <input type="text" value="<?php echo $row['email']; ?>" class="form-control" readonly="">
								 </td>
									<td>
										<?php if($row['role']==1){?>
											<input type="text" value="<?php echo "Admin";?>" class="form-control" readonly=""><?php
										}else{?>
										<input type="text" value="<?php echo "Incharge";?>" class="form-control"readonly=""> <?php
									}?>
								 	</td>
									<td>
											<input type="text" value="<?php echo $row['phone'];?>" class="form-control"readonly="">
									</td>
									<td>
											<!-- Trigger the modal with a button -->
											<button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal-<?php echo $row['user_id']; ?>"><i  class="glyphicon glyphicon-edit"></i>Edit</button>

  										<!-- Modal -->
  										<div class="modal fade" id="myModal-<?php echo $row['user_id']; ?>" role="dialog">
										    <div class="modal-dialog">

										      <!-- Modal content-->
										      <div class="modal-content">
										        <div class="modal-header">
										          <button type="button" class="close" data-dismiss="modal">&times;</button>
										          <h4 class="modal-title">Edit Incharge</h4>
										        </div>

														<form action="<?php echo base_url(); ?>index.php/Add_details/update_user" method="post" name="upload_excel" enctype="multipart/form-data">
															 <div class="modal-body">
																<div class="box-body">
																	<input type="hidden" value="<?php echo $row['user_id']; ?>" name="usr_id">
																		<div class="form-group">
																			<label>Incharge Name</label>
																				<input type="text" name="usr_name" value="<?php echo $row['name']; ?>" class="form-control" required="" >

																		</div>

																		<div class="form-group">
																			<label>Incharge Email</label><span style="color:red;" class="code_status"></span>
																			 <input type="text" name="email" value="<?php echo $row['email']; ?>" class="em form-control" required="" onkeyup="check_email(this.value);">
																		</div>

																		<div class="form-group">
																			<label>Incharge Phone No</label>
																			<input type="text" name="phone" value="<?php echo $row['phone'];?>" class="form-control" required="">
																		</div>

																</div><!-- /.box-body -->

														</div>
														<div class="modal-footer">
										          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
															<input type="submit" value="submit" name="submit"  class="btn btn-primary">
										        </div>
													</form>


										      </div>

										    </div>
										  </div>
									</td>
									<td>
										<!-- Trigger the modal with a button -->
										<button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#myModal2-<?php echo $row['user_id']; ?>"><i  class="glyphicon glyphicon-remove"></i>Delete</button>

										<!-- Modal -->
										<div class="modal fade" id="myModal2-<?php echo $row['user_id']; ?>" role="dialog">
											<div class="modal-dialog">

												<!-- Modal content-->
												<div class="modal-content">
													<div class="modal-header">
														<button type="button" class="close" data-dismiss="modal">&times;</button>
														<h4 class="modal-title">Delete Incharge</h4>
													</div>
													<div class="modal-body">
														 <form action="<?php echo base_url(); ?>index.php/Add_details/delete_user" method="post" name="upload_excel" enctype="multipart/form-data">
															<div class="box-body">
																<input type="hidden" value="<?php echo $row['user_id']; ?>" name="usr_id">
																	<h3>Are You Sure...???</h3>
															</div><!-- /.box-body -->
													<div class="box-footer">
														<center><input type="submit" value="Delete" name="submit"  class="btn btn-primary"></center>
													</div>
												</form>
												</div>
													<div class="modal-footer">
														<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
													</div>
												</div>

											</div>
										</div>
									</td>
							</tr>
						<?php }
	 	       }


					 function get_drugs(){
						 	$i= $this->input->post('i');
							$data  = $this->Fetch_model->get_med($i);
							foreach ($data as $row) {?>
								<tr>
									<td>
										 <input type="text" name="usr_name" value="<?php echo $row['drug_name']; ?>" class="form-control" readonly="">
									 </td>
									<td>
										<input type="text" value="<?php echo $row['quantity'].' '.$row['measure']; ?>" class="form-control" readonly="">
									</td>
									<td>
										<input type="text" value="<?php echo $row['expr_date']; ?>" class="form-control" readonly="">
									</td>
									<td>
										 <!-- Trigger the modal with a button -->
											<button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal-<?php echo $row['drug_id']; ?>"><i  class="glyphicon glyphicon-edit"></i>Edit</button>

											<!-- Modal -->
											 <div class="modal fade" id="myModal-<?php echo $row['drug_id']; ?>" role="dialog">
												 <div class="modal-dialog">
													 <!-- Modal content-->
													 <div class="modal-content">
														 <div class="modal-header">
															 	<button type="button" class="close" data-dismiss="modal">&times;</button>
															 	<h4 class="modal-title">Edit Drugs</h4>
												 		</div>
														 <div class="modal-body">
																<form action="<?php echo base_url(); ?>index.php/Add_details/update_drugs" method="post" name="upload_excel" enctype="multipart/form-data">
		 															<div class="box-body">
																	 	<input type="hidden" value="<?php echo $row['drug_id']; ?>" name="drug_id">
																		 	<div class="form-group">
																			 		<label>	Drug Name</label>
																				 	<input type="text" name="drug_name" value="<?php echo $row['drug_name']; ?>" class="form-control" required="" >
																			 </div>
																			 <div class="form-group">
																			 		<label>Quantity</label>
																			 		<input type="text" name="quantity" value="<?php echo $row['quantity'];?>" class="form-control" required="">
																		 	</div>
																			<div class="form-group">
																				 <label>Measure</label>
																				 <input type="text" name="measure" value="<?php echo $row['measure'];?>" class="form-control" required="">
																		 </div>
																		 <div class="form-group">
																				<label>Exp. Date</label>
																				<input type="text" name="expr_date" value="<?php echo $row['expr_date'];?>" class="form-control" required="">
																		</div>

																		</div><!-- /.box-body -->
														 			<div class="box-footer">
															 			<center><input type="submit" value="submit" name="submit"  class="btn btn-primary"></center>
														 			</div>
													 		</form>
														 </div>
														 <div class="modal-footer">
															 <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
														 </div>
													 	</div>
													</div>
											 </div>
									 </td>
									 <td>
										 <!-- Trigger the modal with a button -->
										 <?php
											 if ($row['trig']=='1'){?>
												  <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#myModal2-<?php echo $row['drug_id']; ?>"><i  class="glyphicon glyphicon-remove"></i>Block</button>
										<?php	 }else{?>

										 <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal2-<?php echo $row['drug_id']; ?>"><i  class="glyphicon glyphicon-remove"></i>Unblock</button>
									 <?php }?>
										 <!-- Modal -->
										 <div class="modal fade" id="myModal2-<?php echo $row['drug_id']; ?>" role="dialog">
											    <div class="modal-dialog modal-sm">

												 <!-- Modal content-->
												 <div class="modal-content">
													 <div class="modal-header">
														 <button type="button" class="close" data-dismiss="modal">&times;</button>
														 <center><h4 class="modal-title">Are You Sure...!!! </h4></center>
													 </div>
													 <div class="modal-body">
															<form action="<?php echo base_url(); ?>index.php/Add_details/delete_drugs" method="post" name="upload_excel" enctype="multipart/form-data">
															 <div class="box-body">
																 <input type="hidden" value="<?php echo $row['drug_id']; ?>" name="drug_id">
																  <input type="hidden" value="<?php echo $row['trig']; ?>" name="trig">

															 </div><!-- /.box-body -->
													 <div class="box-footer">
														 <?php
															if ($row['trig']=='1'){?>
																 <center><input type="submit" value="Yes" name="submit"  class="btn btn-danger btn-sm"></center>
													 <?php	 }else{?>

														 <center><input type="submit" value="Yes." name="submit"  class="btn btn-success btn-sm"></center>
													<?php }?>
													 </div>

												 </form>
												 </div>
													 <div class="modal-footer">
														 <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
													 </div>
												 </div>

											 </div>
										 </div>
									 </td>
							 </tr>
						 <?php }
						}


						function get_test_types_test(){
							 $i= $this->input->post('i');
							 $data  = $this->Fetch_model->get_all_lab_test_tests($i);
							 foreach ($data as $row) {?>
								 <tr>
									 <td>
											<input type="text" name="usr_name" value="<?php echo $row['test_name']; ?>" class="form-control" readonly="">
										</td>

									 <td>
											<!-- Trigger the modal with a button -->
											 <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal-<?php echo $row['test_id']; ?>"><i  class="glyphicon glyphicon-edit"></i>Edit</button>

											 <!-- Modal -->
												<div class="modal fade" id="myModal-<?php echo $row['test_id']; ?>" role="dialog">
													<div class="modal-dialog">
														<!-- Modal content-->
														<div class="modal-content">
															<div class="modal-header">
																 <button type="button" class="close" data-dismiss="modal">&times;</button>
																 <h4 class="modal-title">Edit Drugs</h4>
														 </div>
															<div class="modal-body">
																 <form action="<?php echo base_url(); ?>index.php/Add_details/update_tests" method="post" name="upload_excel" enctype="multipart/form-data">
																	 <div class="box-body">
																		 <input type="hidden" value="<?php echo $row['test_id']; ?>" name="drug_id">
																			 <div class="form-group">
																					 <label>	Test Name</label>
																					 <input type="text" name="drug_name" value="<?php echo $row['test_name']; ?>" class="form-control" required="" >
																				</div>
																				<div class="form-group">
 																					 <label>	Test Range</label>

																					 <textarea class="form-control"  rows="3" name="test_range"  placeholder="Enter Range"  autocomplete="off" required="" >><?php echo $row['test_range']; ?></textarea>
																				</div>

																		 </div><!-- /.box-body -->
																	 <div class="box-footer">
																		 <center><input type="submit" value="submit" name="submit"  class="btn btn-primary"></center>
																	 </div>
															 </form>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
															</div>
														 </div>
													 </div>
												</div>
										</td>
										<td>
											<!-- Trigger the modal with a button -->
											<?php
												if ($row['status']=='1'){?>
													 <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#myModal2-<?php echo $row['test_id']; ?>"><i  class="glyphicon glyphicon-remove"></i>Block</button>
										 <?php	 }else{?>

											<button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal2-<?php echo $row['test_id']; ?>"><i  class="glyphicon glyphicon-remove"></i>Unblock</button>
										<?php }?>
											<!-- Modal -->
											<div class="modal fade" id="myModal2-<?php echo $row['test_id']; ?>" role="dialog">
													 <div class="modal-dialog modal-sm">

													<!-- Modal content-->
													<div class="modal-content">
														<div class="modal-header">
															<button type="button" class="close" data-dismiss="modal">&times;</button>
															<center><h4 class="modal-title">Are You Sure...!!! </h4></center>
														</div>
														<div class="modal-body">
															 <form action="<?php echo base_url(); ?>index.php/Add_details/delete_tests" method="post" name="upload_excel" enctype="multipart/form-data">
																<div class="box-body">
																	<input type="hidden" value="<?php echo $row['test_id']; ?>" name="test_id">
																	 <input type="hidden" value="<?php echo $row['status']; ?>" name="status">

																</div><!-- /.box-body -->
														<div class="box-footer">
															<?php
															 if ($row['status']=='1'){?>
																	<center><input type="submit" value="Yes" name="submit"  class="btn btn-danger btn-sm"></center>
														<?php	 }else{?>

															<center><input type="submit" value="Yes." name="submit"  class="btn btn-success btn-sm"></center>
													 <?php }?>
														</div>

													</form>
													</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
														</div>
													</div>

												</div>
											</div>
										</td>
								</tr>
							<?php }
						 }



}

?>
