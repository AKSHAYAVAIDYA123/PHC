<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fetch_model extends CI_Model
{
 function __construct()
   {
       parent::__construct();

   }

   function get_pat($data){
     $sql=$this->db->query("Select * from patient_register where pat_no= '" .$data."'");
     if( $sql->num_rows() > 0 )
     {
       return $sql->result_array();
     }
     return 0;
   }

   function get_back(){
     $sql=$this->db->query("INSERT INTO stock_ledger (drug_id,phc_code,op_bal,cl_bal)select drug_id,phc_code,quantity,quantity from all_drugs;");
       if($sql){
         return 1;
       }else{
         return 0;
       }

   }
   function get_back_check(){
     $sql=$this->db->query("select *  from stock_ledger where DATE(created_date)=CURDATE()");
     if( $sql->num_rows() > 0 )
     {
       return 1;
     }else{
       return 0;
     }
   }
   function get_notif(){
     $sql=$this->db->query("Select count(*) from drugs_history where status=1 group by phc_code");

       return $sql->num_rows();

   }


   function get_notif1($p){
     $sql=$this->db->query("Select count(*) from drugs_history where status=2 and phc_code='$p' group by phc_code");

       return $sql->num_rows();

   }

//-------------
//drugs stock date wise report old ocode
/*function get_stock($phc,$dt){
 //$sql=$this->db->query("select date(p.date) as dt,a.drug_name ,a.quantity,(p.quantity) as issued ,(a.quantity-sum(p.quantity)) as remaining from all_drugs a LEFT JOIN patient_record p ON a.drug_id=p.drug_id where a.phc_code='".$phc."' group by a.drug_id ,date(p.date)");
 $sql=$this->db->query("select ifnull(date(r.date),CURDATE()) as dat,ifnull((r.date),0) as date_up,a.quantity as cur,a.drug_name,if(date(r.date)=CURDATE(),ifnull(sum(r.quantity),0),0) as is_qty,ifnull((r.rem),a.quantity) as o_b,ifnull(r.rem-sum(r.quantity),a.quantity) as c_b from all_drugs a LEFT JOIN patient_record r ON r.drug_id=a.drug_id and date(r.date)=CURDATE() where a.phc_code='".$phc."' group by a.drug_name");
 if( $sql->num_rows() > 0 )
 {
   return $sql->result_array();
 }
 return 0;
}*/
function get_stock($phc){
 $sql=$this->db->query("select dl.measure,dl.drug_name,sl.op_bal,sl.qty_utilised,sl.qty_requested,sl.qty_added,sl.cl_bal from stock_ledger sl ,all_drugs dl where sl.drug_id=dl.drug_id and date(sl.created_date)=CURDATE() and sl.phc_code='$phc'");
 if( $sql->num_rows() > 0 )
 {
   return $sql->result_array();
 }
 return 0;
}




//****
//drug stock monthly wise report old code
/*function get_stock1($phc,$dt,$yr,$dat){
 //$sql=$this->db->query("select ifnull(month(r.date),'".$dat."') as dat,a.drug_name,if(month(r.date)='".$dt."',ifnull(sum(r.quantity),0),0) is_qty,ifnull(r.rem-sum(r.quantity),a.quantity) as rem from all_drugs a LEFT JOIN patient_record r ON r.drug_id=a.drug_id and month(r.date)='".$dt."' and year(r.date)='".$yr."' where a.phc_code='".$phc."' group by a.drug_name");
 $sql=$this->db->query("select a.drug_id, a.drug_name,if(month(r.date)='".$dt."',ifnull(sum(r.quantity),0),0) as is_qty,ifnull((r.rem),a.quantity) as o_b,r.rem as c_b,ifnull(r.rem-sum(r.quantity),a.quantity) as rem from all_drugs a LEFT JOIN patient_record r ON r.drug_id=a.drug_id and month(r.date)='".$dt."' and year(r.date)='".$yr."' where a.phc_code='".$phc."' group by a.drug_name");

 if( $sql->num_rows() > 0 )
 {
   return $sql->result_array();
 }
 return 0;
}

function get_stock2($i,$m,$y){
 $sql=$this->db->query("select drug_id,sum(cur_quantity) as c_qty,sum(rec_quantity) as rc_qty,sum(req_quantity) as rq_qty from drugs_history where month(month_year)='$m' and year(month_year)='$y' and drug_id='$i' and status=3 group by month_year");
 if( $sql->num_rows() > 0 )
 {
   return $sql->result_array();
 }
 $a=array('drug_id' =>0,'rc_qty'=>0,'rq'=>0);
 return $a;
}*/

//new code for monthly wise report
function get_stock1($phc,$m,$y){
   $sql=$this->db->query("select drug_name,op_bal,cl_bal,req,rec,usd from
   (select sl.drug_id,al.drug_name,sum(sl.qty_requested) as req,sum(sl.qty_utilised) as usd,sum(sl.qty_added) as rec from stock_ledger sl,all_drugs al where sl.drug_id=al.drug_id and month(sl.created_date)='$m' and year(sl.created_date)='$y' and sl.phc_code='$phc' group by sl.drug_id) as s,
   (select drug_id,op_bal from stock_ledger where phc_code='$phc' and date(created_date)=(select date(min(created_date)) from stock_ledger) and month(created_date)='$m' and year(created_date)='$y') l,
   (select drug_id,cl_bal from stock_ledger where phc_code='$phc' and date(created_date)=(select date(max(created_date)) from stock_ledger) and 	month(created_date)='$m' and year(created_date)='$y') t where t.drug_id=l.drug_id and s.drug_id=l.drug_id and t.drug_id=s.drug_id");
   if( $sql->num_rows() > 0 )
   {
     return $sql->result_array();
   }

 return 0;
 }
/***********************/
//to get date wise stock_ledger
function get_stock_by_date($phc,$dt){
 $sql=$this->db->query("select dl.drug_name,sl.op_bal,sl.qty_utilised,sl.qty_requested,sl.qty_added,sl.cl_bal from stock_ledger sl ,all_drugs dl where sl.drug_id=dl.drug_id and date(sl.created_date)='$dt' and sl.phc_code='$phc'");
 if( $sql->num_rows() > 0 )
 {
   return $sql->result_array();
 }
 return 0;
}

function admin_get_stock_by_date($phc,$dt){
 $sql=$this->db->query("select dl.drug_name,sl.op_bal,sl.qty_utilised,sl.qty_requested,sl.qty_added,sl.cl_bal from stock_ledger sl ,all_drugs dl where sl.drug_id=dl.drug_id and date(sl.created_date)='$dt' and sl.phc_code='$phc'");
 if( $sql->num_rows() > 0 )
 {
   return $sql->result_array();
 }
 return 0;
}

//*******************
 /*	to admin all stocks report
 function get_stock(){
     $sql=$this->db->query("select a.drug_name ,a.quantity,(p.quantity) as issued ,(a.quantity-sum(p.quantity)) as remaining from patient_record p RIGHT JOIN all_drugs a ON a.drug_id=p.drug_id group by a.drug_id");
     if( $sql->num_rows() > 0 )
     {
       return $sql->result_array();
     }
     return 0;
   }*/
//--------------------
   function get_otward($phc){
 /* To concat findings,complaints etc if patient data updated twice in a day
     $sql=$this->db->query("select r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.findings separator ',') as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.diagonosis separator ',') as diag,GROUP_CONCAT(r.investigation separator ',') as invest,GROUP_CONCAT(r.treatment separator ',') as treat,GROUP_CONCAT(r.reference separator ',') as ref,GROUP_CONCAT(r.complaints separator ',') as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."'  group by date(r.date),r.op_fileno order by r.pat_id desc");
*/
     $sql=$this->db->query("select r.pat_id,r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment  as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."'  group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
     if( $sql->num_rows() > 0 )
     {
       return $sql->result_array();
     }
     return 0;
   }

   function get_otward2($phc,$f,$t,$a1,$a2,$g,$trt){
  /* To concat findings,complaints etc if patient data updated twice in a day
     $sql=$this->db->query("select r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.findings separator ',') as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.diagonosis separator ',') as diag,GROUP_CONCAT(r.investigation separator ',') as invest,GROUP_CONCAT(r.treatment separator ',') as treat,GROUP_CONCAT(r.reference separator ',') as ref,GROUP_CONCAT(r.complaints separator ',') as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."'  group by date(r.date),r.op_fileno order by r.pat_id desc");
  */
  $sql=$this->db->query("select r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment  as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.visit_type='".$trt."' and r.phc='".$phc."' and p.age >='".$a1."' and p.age <= '".$a2."' and p.sex='".$g."' and date(r.date) >= '".$f."' and date(r.date) <= date('".$t."')   group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
     if( $sql->num_rows() > 0 )
     {
       return $sql->result_array();
     }
     return 0;
   }

   function admin_get_otward($phc){
     /* To concat findings,complaints etc if patient data updated twice in a day
     $sql=$this->db->query("select r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.findings separator ',') as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.diagonosis separator ',') as diag,GROUP_CONCAT(r.investigation separator ',') as invest,GROUP_CONCAT(r.treatment separator ',') as treat,GROUP_CONCAT(r.reference separator ',') as ref,GROUP_CONCAT(r.complaints separator ',') as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."'  group by date(r.date),r.op_fileno order by r.pat_id desc");
     */
       $sql=$this->db->query("select r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.treatment as treat,r.reference as ref,r.complaints  as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."'  group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
     if( $sql->num_rows() > 0 )
     {
       return $sql->result_array();
     }
     return 0;
   }
   //------------------
/*to fetch data to req drugs  old code
   function req_drug($dt,$dt1,$ph){
     //$sql=$this->db->query("select date(p.date) as dt,a.drug_name ,a.quantity,(p.quantity) as issued ,(a.quantity-sum(p.quantity)) as remaining from all_drugs a LEFT JOIN patient_record p ON a.drug_id=p.drug_id where a.phc_code='".$phc."' group by a.drug_id ,date(p.date)");
     $sql=$this->db->query("select a.drug_id,ifnull(MONTH(r.date),'".$dt."') as dat,a.drug_name,if(month(r.date)='".$dt."',ifnull(sum(r.quantity),0),0) is_qty,ifnull(r.rem-sum(r.quantity),a.quantity) as rem from all_drugs a LEFT JOIN patient_record r ON r.drug_id=a.drug_id and MONTH(r.date)='".$dt."' and Year(r.date)='".$dt1."' where a.phc_code='".$ph."' group by a.drug_name;");
     if( $sql->num_rows() > 0 )
     {
       return $sql->result_array();
     }
     return 0;
   }*/
function req_drug($phc){

 $sql=$this->db->query("select dl.drug_name,dl.drug_id,sl.op_bal,sl.qty_utilised,sl.qty_requested,sl.qty_added,sl.cl_bal from stock_ledger sl ,all_drugs dl where sl.drug_id=dl.drug_id and date(sl.created_date)=CURDATE() and sl.phc_code='$phc'");
 if( $sql->num_rows() > 0 )
 {
   return $sql->result_array();
 }
 return 0;

 }
   //----------------
   /*Fetch Visitors-Graph*/
   function getdata($y,$phc){
       $query = $this->db->query('select count(pr_id) as qty ,ifnull(YEAR(date),'.$y.') as date from patient_register  where  rhc_id='.$phc.' and YEAR(date)='.$y.' ');
       if($query){
         return $query->result_array();
       }else{
         return 0;
       }

     }
/*psy date*/
     function get_report_psyCountD_NMale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.reference,r.op_fileno order by r.pat_id desc");
       {
         return $sql->num_rows();
       }
       return 0;
     }
     function get_report_psyCountD_NFmale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Psychiatric Treatment' and date(r.date)= '".$dt."' group by r.reference,r.op_fileno order by r.pat_id desc");
       {
         return $sql->num_rows();
       }
       return 0;
     }


     function get_report_psyCountD_OMale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and date(r.date)= '".$dt."' group by r.reference,r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->num_rows();
       }
       return 0;
     }
     function get_report_psyCountD_OFmale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and date(r.date)= '".$dt."' group by r.reference,r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->num_rows();
       }
       return 0;
     }


        function get_report_psyCountD_NMale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.reference,r.op_fileno order by r.pat_id desc");
       {
         return $sql->num_rows();
       }
       return 0;
     }
     function get_report_psyCountD_NFmale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Psychiatric Treatment' and date(r.date)= '".$dt."' group by r.reference,r.op_fileno order by r.pat_id desc");
       {
         return $sql->num_rows();
       }
       return 0;
     }


     function get_report_psyCountD_OMale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and date(r.date)= '".$dt."' group by r.reference,r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->num_rows();
       }
       return 0;
     }
     function get_report_psyCountD_OFmale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and date(r.date)= '".$dt."' group by r.reference,r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->num_rows();
       }
       return 0;
     }



     function get_report_psy($phc,$dt){

       $sql=$this->db->query("select r.pat_id,r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,p.pat_place,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment  as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and r.visit_type='Psychiatric Treatment' and date(r.date)= '".$dt."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->result_array();
       }
       return 0;
     }
/*-----------psy week------*/
function get_report_psyCountD_N_WMale($phc,$dt){
  $var = explode('-',$dt);
  $date1 = date('Y-m-d',strtotime($var[0]));
  $date2 = date('Y-m-d',strtotime($var[1]));
  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and r.phc='".$phc."' and p.age>5 and r.patV_type='1' and r.visit_type='Psychiatric Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
       return $sql->num_rows();
  }
  return 0;
}
function get_report_psyCountD_N_WFmale($phc,$dt){
  $var = explode('-',$dt);
  $date1 = date('Y-m-d',strtotime($var[0]));
  $date2 = date('Y-m-d',strtotime($var[1]));
  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and r.phc='".$phc."' and p.age>5 and r.patV_type='1' and r.visit_type='Psychiatric Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
       return $sql->num_rows();
  }
  return 0;
}

function get_report_psyCountD_O_WMale($phc,$dt){
  $var = explode('-',$dt);
  $date1 = date('Y-m-d',strtotime($var[0]));
  $date2 = date('Y-m-d',strtotime($var[1]));
  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and r.phc='".$phc."' and p.age>5 and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
      return $sql->num_rows();
  }
  return 0;
}
function get_report_psyCountD_O_WFmale($phc,$dt){
  $var = explode('-',$dt);
  $date1 = date('Y-m-d',strtotime($var[0]));
  $date2 = date('Y-m-d',strtotime($var[1]));
  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and r.phc='".$phc."' and p.age>5 and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
      return $sql->num_rows();
  }
  return 0;
}


/*ADDD */
function get_report_psyCountD_N_WMale1($phc,$dt){
  $var = explode('-',$dt);
  $date1 = date('Y-m-d',strtotime($var[0]));
  $date2 = date('Y-m-d',strtotime($var[1]));
  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and r.phc='".$phc."' and p.age<6 and r.patV_type='1' and r.visit_type='Psychiatric Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
       return $sql->num_rows();
  }
  return 0;
}
function get_report_psyCountD_N_WFmale1($phc,$dt){
  $var = explode('-',$dt);
  $date1 = date('Y-m-d',strtotime($var[0]));
  $date2 = date('Y-m-d',strtotime($var[1]));
  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and r.phc='".$phc."' and p.age<6 and r.patV_type='1' and r.visit_type='Psychiatric Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
       return $sql->num_rows();
  }
  return 0;
}

function get_report_psyCountD_O_WMale1($phc,$dt){
  $var = explode('-',$dt);
  $date1 = date('Y-m-d',strtotime($var[0]));
  $date2 = date('Y-m-d',strtotime($var[1]));
  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and r.phc='".$phc."' and p.age<6 and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
      return $sql->num_rows();
  }
  return 0;
}
function get_report_psyCountD_O_WFmale1($phc,$dt){
  $var = explode('-',$dt);
  $date1 = date('Y-m-d',strtotime($var[0]));
  $date2 = date('Y-m-d',strtotime($var[1]));
  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and r.phc='".$phc."' and p.age<6 and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
      return $sql->num_rows();
  }
  return 0;
}



     function get_report_psyW($phc,$dt){
        $var = explode('-',$dt);
        $date1 = date('Y-m-d',strtotime($var[0]));
        $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select r.pat_id,r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,p.pat_place,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment  as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and r.visit_type='Psychiatric Treatment' and  date(r.date) BETWEEN '".$date1."' AND  '".$date2."'  group by date(r.date),r.reference,r.op_fileno order by  r.date asc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->result_array();
       }
       return 0;
     }
/*--------psy month-------*/
function get_report_psyCountD_N_MMale($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Psychiatric Treatment' and month(r.date)= '".$dt."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
function get_report_psyCountD_N_MFmale($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Psychiatric Treatment' and month(r.date)= '".$dt."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}


function get_report_psyCountD_O_MMale($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and month(r.date)= '".$dt."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
function get_report_psyCountD_O_MFmale($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and month(r.date)= '".$dt."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}


/***/
function get_report_psyCountD_N_MMale1($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Psychiatric Treatment' and month(r.date)= '".$dt."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
function get_report_psyCountD_N_MFmale1($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Psychiatric Treatment' and month(r.date)= '".$dt."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}


function get_report_psyCountD_O_MMale1($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and month(r.date)= '".$dt."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
function get_report_psyCountD_O_MFmale1($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Psychiatric Treatment' and month(r.date)= '".$dt."' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
     function get_report_psyM($phc,$dt){

       $sql=$this->db->query("select r.pat_id,r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,p.pat_place,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and r.visit_type='Psychiatric Treatment' and month(r.date)= '".$dt."' group by date(r.date),r.reference,r.op_fileno order by  r.date asc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->result_array();
       }
       return 0;
     }

/***dent adte**/
function get_report_dentCountD_NMale($phc,$dt){

  $sql=$this->db->query("select COUNT(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Dental Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
       return $sql->num_rows();
  }
  return 0;
}
function get_report_dentCountD_NFmale($phc,$dt){

  $sql=$this->db->query("select COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Dental Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
       return $sql->num_rows();
  }
  return 0;
}


function get_report_dentCountD_OMale($phc,$dt){

  $sql=$this->db->query("select COUNT(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Dental Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
function get_report_dentCountD_OFmale($phc,$dt){

  $sql=$this->db->query("select COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Dental Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}


function get_report_dentCountD_OMale1($phc,$dt){

  $sql=$this->db->query("select COUNT(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Dental Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
function get_report_dentCountD_OFmale1($phc,$dt){

  $sql=$this->db->query("select COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Dental Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}


/**/
function get_report_dentCountD_NMale1($phc,$dt){

  $sql=$this->db->query("select COUNT(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Dental Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
       return $sql->num_rows();
  }
  return 0;
}
function get_report_dentCountD_NFmale1($phc,$dt){

  $sql=$this->db->query("select COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Dental Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
       return $sql->num_rows();
  }
  return 0;
}
 


 
     function get_report_dent($phc,$dt){

       $sql=$this->db->query("select r.pat_id,r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,p.pat_place,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment  as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and r.visit_type='Dental Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->result_array();
       }
       return 0;
     }
/*----------dent week*********/
     function get_report_dentCountD_N_WMale($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Dental Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
            return $sql->num_rows();
       }
       return 0;
     }
     function get_report_dentCountD_N_WFmale($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Dental Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
            return $sql->num_rows();
       }
       return 0;
     }

     function get_report_dentCountD_O_WMale($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Dental Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
           return $sql->num_rows();
       }
       return 0;
     }
     function get_report_dentCountD_O_WFmale($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Dental Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
           return $sql->num_rows();
       }
       return 0;
     }


       function get_report_dentCountD_N_WMale1($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Dental Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
            return $sql->num_rows();
       }
       return 0;
     }
     function get_report_dentCountD_N_WFmale1($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Dental Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
            return $sql->num_rows();
       }
       return 0;
     }

     function get_report_dentCountD_O_WMale1($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Dental Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
           return $sql->num_rows();
       }
       return 0;
     }
     function get_report_dentCountD_O_WFmale1($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Dental Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
           return $sql->num_rows();
       }
       return 0;
     }

     function get_report_dentW($phc,$dt){
        $var = explode('-',$dt);
        $date1 = date('Y-m-d',strtotime($var[0]));
        $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select r.pat_id,r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,p.pat_place,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment  as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and r.visit_type='Dental Treatment' and  date(r.date) BETWEEN '".$date1."' AND  '".$date2."'  group by r.op_fileno order by  r.date asc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->result_array();
       }
       return 0;
     }

/*DEnt month*/
function get_report_dentCountD_N_MMale($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and r.phc='".$phc."' and r.patV_type='1' and p.age>5 and r.visit_type='Dental Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
function get_report_dentCountD_N_MFmale($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and r.phc='".$phc."' and r.patV_type='1' and p.age>5 and r.visit_type='Dental Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}


function get_report_dentCountD_O_MMale($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and r.phc='".$phc."' and r.patV_type='0' and p.age>5 and r.visit_type='Dental Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
function get_report_dentCountD_O_MFmale($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and r.phc='".$phc."' and r.patV_type='0'and p.age>5 and r.visit_type='Dental Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}


function get_report_dentCountD_N_MMale1($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and r.phc='".$phc."' and r.patV_type='1' and p.age<6 and r.visit_type='Dental Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
function get_report_dentCountD_N_MFmale1($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and r.phc='".$phc."' and r.patV_type='1' and p.age<6 and r.visit_type='Dental Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}


function get_report_dentCountD_O_MMale1($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and r.phc='".$phc."' and r.patV_type='0' and p.age<6 and r.visit_type='Dental Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
function get_report_dentCountD_O_MFmale1($phc,$dt){

  $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and r.phc='".$phc."' and r.patV_type='0'and p.age<6 and r.visit_type='Dental Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
  if( $sql->num_rows() > 0 )
  {
     return $sql->num_rows();
  }
  return 0;
}
     function get_report_dentM($phc,$dt){

       $sql=$this->db->query("select r.pat_id,r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,p.pat_place,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and r.visit_type='Dental Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by  r.date asc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->result_array();
       }
       return 0;
     }

/*----------Medical--------------*/
     function get_report_medCountD_NMale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       {
         return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_NFmale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       {
         return $sql->num_rows();
       }
       return 0;
     }
	 
      function get_report_medCountD_NMale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and p.age<6 and r.patV_type='1' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       {
         return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_NFmale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and p.age<6 and r.patV_type='1' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       {
         return $sql->num_rows();
       }
       return 0;
     }
	 
 

 

     function get_report_medCountD_OMale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_OFmale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->num_rows();
       }
       return 0;
     }
	 
	 
	 function get_report_medCountD_OMale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , SUM(p.sex) as male  from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_OFmale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total , COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->num_rows();
       }
       return 0;
     }
	 
	 


     function get_report_med($phc,$dt){

       $sql=$this->db->query("select r.pat_id,r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,p.pat_place,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment  as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and r.visit_type='Medical Treatment' and date(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->result_array();
       }
       return 0;
     }
/*Medical week*/
    
       function get_report_medCountD_N_WMale($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
            return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_N_WFmale($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
            return $sql->num_rows();
       }
       return 0;
     }

        function get_report_medCountD_N_WMale1($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
            return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_N_WFmale1($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
            return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_O_WMale($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1  and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
           return $sql->num_rows();
       }
       return 0;
     }

          function get_report_medCountD_O_WMale1($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1  and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
           return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_O_WFmale($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
           return $sql->num_rows();
       }
       return 0;
     }

         function get_report_medCountD_O_WFmale1($phc,$dt){
       $var = explode('-',$dt);
       $date1 = date('Y-m-d',strtotime($var[0]));
       $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and date(r.date) BETWEEN '".$date1."' AND  '".$date2."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
           return $sql->num_rows();
       }
       return 0;
     }



     function get_report_medW($phc,$dt){
        $var = explode('-',$dt);
        $date1 = date('Y-m-d',strtotime($var[0]));
        $date2 = date('Y-m-d',strtotime($var[1]));
       $sql=$this->db->query("select r.pat_id,r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,p.pat_place,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment  as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and r.visit_type='Medical Treatment' and  date(r.date) BETWEEN '".$date1."' AND  '".$date2."'  group by r.op_fileno order by  r.date asc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->result_array();
       }
       return 0;
     }


/*Med month*/

     function get_report_medCountD_N_MMale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
          return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_N_MFmale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
          return $sql->num_rows();
       }
       return 0;
     }

          function get_report_medCountD_N_MMale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
          return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_N_MFmale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='1' and r.visit_type='Medical Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
          return $sql->num_rows();
       }
       return 0;
     }





     function get_report_medCountD_O_MMale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
          return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_O_MFmale($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age>5 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
          return $sql->num_rows();
       }
       return 0;
     }

   function get_report_medCountD_O_MMale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as male from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=1 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
          return $sql->num_rows();
       }
       return 0;
     }
     function get_report_medCountD_O_MFmale1($phc,$dt){

       $sql=$this->db->query("select COUNT(r.pat_id) as total ,COUNT(p.sex) as fmale from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where p.sex=2 and p.age<6 and r.phc='".$phc."' and r.patV_type='0' and r.visit_type='Medical Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by r.pat_id desc");
       if( $sql->num_rows() > 0 )
       {
          return $sql->num_rows();
       }
       return 0;
     }

     function get_report_medM($phc,$dt){

       $sql=$this->db->query("select r.pat_id,r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,p.pat_place,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis as diag,r.investigation as invest,r.visit_type,r.treatment as treat,r.reference as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and r.visit_type='Medical Treatment' and month(r.date)= '".$dt."' group by r.op_fileno order by  r.date asc");
       if( $sql->num_rows() > 0 )
       {
         return $sql->result_array();
       }
       return 0;
     }


     function get_labdata($y,$m){


       $query = $this->db->query('select sum(if(sex = 1,1,0)) as m,sum(if(sex = 2,1,0)) as f,ifnull(MONTHNAME(dates),'.$m.') as date, sum(if((age<10)&&(sex=1),1,0)) as mc, sum(if((age<10)&&(sex=2),1,0)) as fc from lab_patients where if_ref=0 and YEAR(dates)='.$y.' and MONTH(dates)='.$m.' ');
           if($query){
             return $query->result_array();
           }else{
             return 0;
           }


       }

       function get_labdata_ref($y,$m){


         $query = $this->db->query('select sum(if(sex = 1,1,0)) as m,sum(if(sex = 2,1,0)) as f,ifnull(MONTHNAME(dates),'.$m.') as date, sum(if((age<10)&&(sex=1),1,0)) as mc, sum(if((age<10)&&(sex=2),1,0)) as fc from lab_patients where if_ref=1 and YEAR(dates)='.$y.' and MONTH(dates)='.$m.' ');
         if($query){
           return $query->result_array();
         }else{
           return 0;
         }

         }
         function get_labdata_ref2($y,$m){
           $query = $this->db->query('select sum(if(sex=1,1,0)) as m,ifnull(MONTHNAME(dates),'.$m.') as date,sum(if(sex=2,1,0)) as f from lab_patients where YEAR(dates)='.$y.' and MONTH(dates)='.$m.' ');
           if($query){
             return $query->result_array();
           }else{
             return 0;
           }

           }
     function getpat_det($id){
       $sql = $this->db->query("select * from patient_register p,phc r where p.rhc_id=r.phc_code and  p.pat_no=".$id);
           if( $sql->num_rows() > 0 )
          {
           return $sql->result_array();
         }return 0;

       }
       //--------------------
           function get_pat_history($phc,$id){
                 /* To concat findings,complaints etc if patient data updated twice in a day
             $sql=$this->db->query("select r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.findings separator ',\n') as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.diagonosis separator ',\n') as diag,GROUP_CONCAT(r.investigation separator ',\n') as invest,GROUP_CONCAT(r.treatment separator ',\n') as treat,GROUP_CONCAT(r.reference separator ',\n') as ref,GROUP_CONCAT(r.complaints separator ',\n') as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and p.pat_no='".$id."' group by date(r.date),r.op_fileno order by r.pat_id desc");
*/
             $sql=$this->db->query("select r.pat_id,r.drug_id ,r.visit_type,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings  as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis  as diag,r.investigation as invest,r.treatment  as treat,r.reference  as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and p.pat_no='".$id."' and r.visit_type='Medical Treatment' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
             if( $sql->num_rows() > 0 )
             {
               return $sql->result_array();
             }
             return 0;
           }

           function get_pat_history_dent($phc,$id){
                 /* To concat findings,complaints etc if patient data updated twice in a day
             $sql=$this->db->query("select r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.findings separator ',\n') as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.diagonosis separator ',\n') as diag,GROUP_CONCAT(r.investigation separator ',\n') as invest,GROUP_CONCAT(r.treatment separator ',\n') as treat,GROUP_CONCAT(r.reference separator ',\n') as ref,GROUP_CONCAT(r.complaints separator ',\n') as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and p.pat_no='".$id."' group by date(r.date),r.op_fileno order by r.pat_id desc");
*/
             $sql=$this->db->query("select r.pat_id,r.drug_id ,r.visit_type,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings  as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis  as diag,r.investigation as invest,r.treatment  as treat,r.reference  as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and p.pat_no='".$id."' and r.visit_type='Dental Treatment' group by date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
             if( $sql->num_rows() > 0 )
             {
               return $sql->result_array();
             }
             return 0;
           }

           function get_pat_history_psy($phc,$id){
                 /* To concat findings,complaints etc if patient data updated twice in a day
             $sql=$this->db->query("select r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.findings separator ',\n') as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.diagonosis separator ',\n') as diag,GROUP_CONCAT(r.investigation separator ',\n') as invest,GROUP_CONCAT(r.treatment separator ',\n') as treat,GROUP_CONCAT(r.reference separator ',\n') as ref,GROUP_CONCAT(r.complaints separator ',\n') as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and p.pat_no='".$id."' group by date(r.date),r.op_fileno order by r.pat_id desc");
*/
             $sql=$this->db->query("select r.pat_id,r.pat_id,r.drug_id ,r.visit_type,date(r.date) as dt,p.pat_no,p.pat_name,p.age,p.sex,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.findings  as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,r.diagonosis  as diag,r.investigation as invest,r.treatment  as treat,r.reference  as ref,r.complaints as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno where r.phc='".$phc."' and p.pat_no='".$id."' and r.visit_type='Psychiatric Treatment' group by  date(r.date),r.reference,r.op_fileno order by r.pat_id desc");
             if( $sql->num_rows() > 0 )
             {
               return $sql->result_array();
             }
             return 0;
           }


           //------------------
           function get_ref_pat($y){


                 $query = $this->db->query("select * from phc p, referred r where p.phc_code=r.phc_id and  r.ref_id=".$y);

                 return $query->result_array();

             }

             function get_ref_pat1($y){


                   $query = $this->db->query("select * from lab_patients l, lab_patient_record lp, tests t where l.pat_id=lp.lab_reg_id and t.test_id=lp.lab_tests and lp.lab_reg_id=".$y);

                   return $query->result_array();

               }

           //get all users
           function get_incharge($y){


                 $query = $this->db->query("select * from users where phc_code=".$y);

                 return $query->result_array();

             }

             function get_phc_name($y){


                   $query = $this->db->query("select * from phc where phc_code=".$y);

                   return $query->result_array();

               }
               function get_all_lab_test_results($a){
                 $query = $this->db->query("select * from lab_patient_record l,tests t ,lab_tests c where t.test_type=c.test_id and t.test_id=l.lab_tests and l.lab_reg_id=".$a);

                   return $query->result_array();

                 }


         //get drug by phc

         function get_med($y){


               $query = $this->db->query("select * from all_drugs where phc_code=".$y);

               return $query->result_array();

           }

           function req_drug_pending($phc){


                 $query = $this->db->query("select * from drugs_history h ,all_drugs a  where h.drug_id=a.drug_id and h.req_quantity <> 0  and h.status=0  and h.phc_code=".$phc);

                 return $query->result_array();

             }

             function req_drug_admin($phc){


                   $query = $this->db->query("select * from drugs_history h ,all_drugs a  where h.drug_id=a.drug_id and h.req_quantity <> 1  and h.status=1 and h.phc_code='$phc'");

                   return $query->result_array();

               }

               function req_drug_status($phc){
                   $query = $this->db->query("select * from drugs_history h ,all_drugs a  where h.drug_id=a.drug_id and h.req_quantity <> 0  and h.status=2  and h.phc_code=".$phc);
                   return $query->result_array();

                 }

                 function get_drug_warning($phc){
                   $query = $this->db->query("select * from all_drugs where expr_date=DATE_ADD(CURDATE(),INTERVAL -2 DAY) and phc_code=".$phc);
                   return $query->num_rows();

                   }

                   function get_all_drug_warning($phc){
                     $query = $this->db->query("select * from all_drugs where expr_date=DATE_ADD(CURDATE(),INTERVAL -2 DAY) and phc_code=".$phc);
                       return $query->result_array();

                     }
                     function get_all_lab_test_blood(){
                       $query = $this->db->query("select * from tests where test_type=1");

                         return $query->result_array();

                       }
                     function get_all_lab_test_tests($a){
                       $query = $this->db->query("select * from tests where test_type=".$a);

                         return $query->result_array();

                       }

                       function get_all_lab_test_urine(){
                         $query = $this->db->query("select * from tests where test_type=2");

                           return $query->result_array();

                         }
                         function get_all_test_types(){
                           $sql=$this->db->query("Select * from lab_tests");

                           return $sql->result_array();

                         }

                         function get_all_test_types1($id){
                           $sql=$this->db->query("Select * from lab_tests where phc_code=".$id);

                           return $sql->result_array();

                         }

}



?>
