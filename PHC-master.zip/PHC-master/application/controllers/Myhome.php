<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Myhome extends CI_Controller {

	 public function __construct() {
     parent::__construct();
		 $this->load->database();
		  $this->load->model(array('Add_model','Fetch_model','User_model','Update_model','Csv_model'));
		 $this->load->library('session');
			$this->load->helper(array('form','url'));
	//		$CI =& get_instance();

   }

	 public function log_sucess(){
	 		if($this->session->userdata('Login')){
	 				$session=$this->session->userdata('Login');
	 				$user['user_id']=$session['id'];
	 				$user['email']=$session['email'];
	 				$user['name']=$session['name'];
					$user['role']=$session['role'];
					$user['phc_code']=$session['phc_code'];
					$result=$this->User_model->get_phc_by_id($user['phc_code']);
					$user['phc']=$result;
					$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
					$user['warning']=$warn;

					$back=$this->Fetch_model->get_back_check();
					if($back==0){
							$back1=$this->Fetch_model->get_back();
					}


					$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
					$user['all_warning']=$a_warn;


					$result=$this->Fetch_model->get_stock($user['phc_code']);
					$user['stock']=$result;
					$user['title']="Welcome-".$user['name'];

	 				$this->load->view('new/welcome_home',$user);
	 		}else{
	 			redirect('/', 'refresh');
	 		}
		}

		public function search_my_pst(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$result=$this->User_model->get_phc_by_id($user['phc_code']);
				$user['phc']=$result;

				$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
				$user['warning']=$warn;
				$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
				$user['all_warning']=$a_warn;
				$user['title']="Search";
				$this->load->view('new/search_my_pst',$user);
		}else{
			redirect('/', 'refresh');
		}
	}


 	public function out_pat(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$result=$this->User_model->get_phc_by_id($user['phc_code']);
				$user['phc']=$result;

				$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
				$user['warning']=$warn;
				$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
				$user['all_warning']=$a_warn;
				$user['title']="Out Patient Register";
				$this->load->view('new/out_patient',$user);
		}else{
			redirect('/', 'refresh');
		}
	}

	public function out_reg($str){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$user['auto_id']=base64_decode($str);
				$result=$this->User_model->get_drug();
				$user['drug_name']=$result;

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$user['title']="Registration Details";
				$this->load->view('new/out_register',$user);
		}else{
			redirect('/', 'refresh');
		}
	}

	public function pat_hist(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$in = $this->session->flashdata('in');
				 if($in==1)
				  {
					$user['suc']=$in;
				}

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$user['title']="Out Patient Record";
				$this->load->view('new/patient_det',$user);
		}else{
			redirect('/', 'refresh');
		}
	}

	public function edit_pat_hist(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$in = $this->session->flashdata('in');
				 if($in==1)
				  {
					$user['suc']=$in;
				}

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$user['title']="Out Patient Record";
				$this->load->view('new/edit_patient_det',$user);
		}else{
			redirect('/', 'refresh');
		}
	}

	public function map_stat(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$in = $this->session->flashdata('in');
				 if($in==1)
				  {
					$user['suc']=$in;
				}

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$user['title']="Out Patient Record";
			//	$this->load->view('new/map',$user);
				redirect('http://localhost/PHC-master/google/');
		}else{
			redirect('/', 'refresh');
		}
	}

	public function phc_add(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$user['title']="Add New PHC";
				$this->load->view('new/health_center',$user);

		}else{
			redirect('/', 'refresh');
		}
	}
	public function graph(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
				$user['warning']=$warn;
				$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
				$user['all_warning']=$a_warn;
				$user['title']="Graph";
				$this->load->view('new/ask_graph',$user);
		}else{
			redirect('/', 'refresh');
		}
	}
	public function lab_stat(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
				$user['warning']=$warn;
				$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
				$user['all_warning']=$a_warn;
				$user['title']="Statistics";
				$this->load->view('new/lab_ask_stat',$user);
		}else{
			redirect('/', 'refresh');
		}
	}


	public function doctor_add(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$result=$this->User_model->get_phc();
				$user['phc']=$result;
				$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
				$user['warning']=$warn;
				$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
				$user['all_warning']=$a_warn;
				$user['title']="Add New Doctor";
				$this->load->view('new/doctor',$user);
		}else{
			redirect('/', 'refresh');
		}
	}

	public function drugs_add(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$result=$this->User_model->get_phc();
				$user['phc']=$result;
				$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
				$user['warning']=$warn;
				$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
				$user['all_warning']=$a_warn;
				$user['title']="Add New Drugs";
				$this->load->view('new/drugs',$user);
		}else{
			redirect('/', 'refresh');
		}
	}

	public function stock_det(){
		if($this->session->userdata('Login')){
			 $this->load->model('Fetch_model');
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$user['title']="Drugs Stock Register";
				$pdt=date('Y-m-d');
		//		$result=$this->Fetch_model->get_stock($user['phc_code'],$pdt);
			//	if($result==0){
				//	$user['stock']=0;
					//$this->load->view('new/drugs_stock',$user);
			//	}else{
			//		$user['stock']=$result;
					$this->load->view('new/drugs_stock',$user);
			//	}

		}else{
			redirect('/', 'refresh');
		}
	}

	public function admin_stock_det(){
		if($this->session->userdata('Login')){
			 $this->load->model('Fetch_model');
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$user['title']="Drugs Stock Register";

					$result=$this->User_model->get_phc();
					$user['phc']=$result;
					$this->load->view('new/admin_drugs_stock',$user);


		}else{
			redirect('/', 'refresh');
		}
	}

	public function ot_ward_det(){
		if($this->session->userdata('Login')){
			 $this->load->model('Fetch_model');
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$user['title']="Drugs Outward Register";

				$result=$this->Fetch_model->get_otward($user['phc_code']);
				$user['stock']=$result;

							$resultq=$this->User_model->get_phc();
							$user['ref_phc']=$resultq;
									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


					$this->load->view('new/out_ward_reg',$user);

		}else{
			redirect('/', 'refresh');
		}
	}

	public function admin_ot_ward_det(){
		if($this->session->userdata('Login')){
			 $this->load->model('Fetch_model');
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$result=$this->User_model->get_phc();
				$user['phc']=$result;

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;



				$user['title']="Drugs Outward Register";
				$this->load->view('new/admin_out_ward_reg',$user);

		}else{
			redirect('/', 'refresh');
		}
	}

	public function user_add(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$result=$this->User_model->get_phc();
				$user['phc']=$result;

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$user['title']="Add New User";
				$this->load->view('new/user_register',$user);
		}else{
			redirect('/', 'refresh');
		}
	}

	public function d_req_form(){
		if($this->session->userdata('Login')){
			$this->load->model('Fetch_model');
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
				$dt=date('Y-m-d');
 				$user['title']="Medicine Indent Form";
				 $d = date("m", strtotime($dt));
				 $d1 = date("Y", strtotime($dt));


				 $result=$this->Fetch_model->req_drug($user['phc_code']);
					$user['stock']=$result;
					$user['req_date']=$dt;

										$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
										$user['warning']=$warn;

										$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
										$user['all_warning']=$a_warn;



					 $this->load->view('new/drug_req',$user);


		}else{
		 redirect('/', 'refresh');
		}
	}

	public function d_req_pending(){
		if($this->session->userdata('Login')){
			$this->load->model('Fetch_model');
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
				$dt=date('Y-m-d');
				$user['title']="Medicine Indent Request Confirmation";
				$result=$this->Fetch_model->req_drug_pending($user['phc_code']);
					$user['stock']=$result;
					$user['req_date']=$dt;

										$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
										$user['warning']=$warn;

										$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
										$user['all_warning']=$a_warn;


					 $this->load->view('new/req_pending',$user);

		}else{
		 redirect('/', 'refresh');
		}
	}
	public function d_req_status(){
		if($this->session->userdata('Login')){
			$this->load->model('Fetch_model');
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
				$dt=date('Y-m-d');
 				$user['title']="Medicine Indent Request Status";
				$result=$this->Fetch_model->req_drug_status($user['phc_code']);
					$user['stock']=$result;
					$user['req_date']=$dt;

										$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
										$user['warning']=$warn;

										$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
										$user['all_warning']=$a_warn;


					 $this->load->view('new/req_status',$user);

		}else{
		 redirect('/', 'refresh');
		}
	}

	public function admin_req_indent(){
		if($this->session->userdata('Login')){
			$this->load->model('Fetch_model');
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
				$dt=date('Y-m-d');
 				$user['title']="Drugs Indent Request";
				$result=$this->User_model->get_req_phc();
				$user['all_phc']=$result;
				//$result=$this->Fetch_model->req_drug_admin($user['phc_code']);
					//$user['stock']=$result;
					//$user['req_date']=$dt;

										$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
										$user['warning']=$warn;

										$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
										$user['all_warning']=$a_warn;



					 $this->load->view('new/admin_req',$user);

		}else{
		 redirect('/', 'refresh');
		}
	}


	public function modify_incharge(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$result=$this->User_model->get_phc();
				$user['phc']=$result;
				$user['title']="Edit/Delete Incharge";

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$this->load->view('new/edit_incharge',$user);
		}else{
			redirect('/', 'refresh');
		}
	}

	public function modify_phc(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$result=$this->User_model->get_phc();
				$user['phc']=$result;
				$user['title']="Edit/Delete PHC";

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$this->load->view('new/edit_phc',$user);
		}else{
			redirect('/', 'refresh');
		}
	}

	public function modify_drugs(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				if($user['role']!=1){
					$result=$this->User_model->get_phc_by_id($user['phc_code']);
					$user['phc']=$result;
				}else{
					$result=$this->User_model->get_phc();
					$user['phc']=$result;
				}
				$result=$this->User_model->get_drug();
				$user['drug']=$result;
				$user['title']="Edit/Delete Drugs";

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;


				$this->load->view('new/edit_drugs',$user);
		}else{
			redirect('/', 'refresh');
		}
	}
	public function modify_lab_comp(){
		if($this->session->userdata('Login')){
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				if($user['role']!=1){
					$result=$this->User_model->get_phc_by_id($user['phc_code']);
					$user['phc']=$result;
				}else{
					$result=$this->Fetch_model->get_tests();
					$user['phc']=$result;
				}

				if($user['role']!=1){
					$result=$this->Fetch_model->get_all_test_types1($user['phc_code']);
					$user['test']=$result;
				}else{
					$result=$this->Fetch_model->get_all_test_types();
					$user['test']=$result;
				}


				$result=$this->User_model->get_drug();
				$user['drug']=$result;
				$user['title']="Edit/Delete Lab Components";

									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;

									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;
									$lab_tests=$this->Fetch_model->get_all_test_types1($user['phc_code']);
									$user['lab_test_types']=$lab_tests;

				$this->load->view('new/edit_lab_comp',$user);
		}else{
			redirect('/', 'refresh');
		}
	}


		public function drugs_expr(){
			if($this->session->userdata('Login')){
					$session=$this->session->userdata('Login');
					$user['user_id']=$session['id'];
					$user['email']=$session['email'];
					$user['name']=$session['name'];
					$user['role']=$session['role'];
					$user['phc_code']=$session['phc_code'];

										$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
										$user['warning']=$warn;

										$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
										$user['all_warning']=$a_warn;



			}else{
				redirect('/', 'refresh');
			}
		}
		public function choice(){
			if($this->session->userdata('Login')){
					$session=$this->session->userdata('Login');
					$user['user_id']=$session['id'];
					$user['email']=$session['email'];
					$user['name']=$session['name'];
					$user['role']=$session['role'];
					$user['phc_code']=$session['phc_code'];
					$in = $this->session->flashdata('in');
					 if($in==1)
					  {
						$user['suc']=$in;
					}
										$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
										$user['warning']=$warn;

										$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
										$user['all_warning']=$a_warn;
											$user['title']="Lab Register";
											$result=$this->User_model->get_phc();
											$user['phc']=$result;
								//		$this->load->view('new/choice',$user);
								$this->load->view('new/lab_search',$user);


			}else{
				redirect('/', 'refresh');
			}
		}
		public function lab_component1(){
			if($this->session->userdata('Login')){
					$session=$this->session->userdata('Login');
					$user['user_id']=$session['id'];
					$user['email']=$session['email'];
					$user['name']=$session['name'];
					$user['role']=$session['role'];
					$user['phc_code']=$session['phc_code'];
					$in = $this->session->flashdata('in');
					 if($in==1)
					  {
						$user['suc']=$in;
					}
										$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
										$user['warning']=$warn;

										$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
										$user['all_warning']=$a_warn;
											$user['title']="Lab Register";
											$result=$this->User_model->get_phc();
											$user['phc']=$result;
								//		$this->load->view('new/choice',$user);
								$this->load->view('new/lab_search_tech',$user);


			}else{
				redirect('/', 'refresh');
			}
		}



		public function lab_components(){
			if($this->session->userdata('Login')){
					$session=$this->session->userdata('Login');
					$user['user_id']=$session['id'];
					$user['email']=$session['email'];
					$user['name']=$session['name'];
					$user['role']=$session['role'];
					$user['phc_code']=$session['phc_code'];

					//$result=$this->User_model->get_phc_by_id($user['phc_code']);
					//$user['phc']=$result;


						$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
						$user['warning']=$warn;
						$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
						$user['all_warning']=$a_warn;

						$lab_types=$this->Fetch_model->get_all_test_types1($user['phc_code']);
						$user['lab_types']=$lab_types;

						$lab_tests=$this->Fetch_model->get_all_lab_test_blood();//$user['phc_code']);
						$user['lab_test']=$lab_tests;

						$lab_tests=$this->Fetch_model->get_all_lab_test_urine();//$user['phc_code']);
						$user['lab_tests']=$lab_tests;


					$user['title']="Lab Register";
					$this->load->view('new/lab_search',$user);
			}else{
				redirect('/', 'refresh');
			}
		}


		public function lab_component(){
			if($this->session->userdata('Login')){
					$session=$this->session->userdata('Login');
					$user['user_id']=$session['id'];
					$user['email']=$session['email'];
					$user['name']=$session['name'];
					$user['role']=$session['role'];
					$user['phc_code']=$session['phc_code'];

					//$result=$this->User_model->get_phc_by_id($user['phc_code']);
					//$user['phc']=$result;


						$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
						$user['warning']=$warn;
						$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
						$user['all_warning']=$a_warn;

						$lab_types=$this->Fetch_model->get_all_test_types1($user['phc_code']);
						$user['lab_types']=$lab_types;

						$lab_tests=$this->Fetch_model->get_all_lab_test_blood();//$user['phc_code']);
						$user['lab_test']=$lab_tests;
						$lab_tests=$this->Fetch_model->get_all_lab_test_urine();//$user['phc_code']);
						$user['lab_tests']=$lab_tests;

						$phc_name=$this->Fetch_model->get_phc_name($user['phc_code']);
						$user['phc_name']=$phc_name;

					$user['title']="Lab Register";
					$this->load->view('new/lab_comp_new',$user);
			}else{
				redirect('/', 'refresh');
			}
		}
		public function fun($a)
		{
			$lab_tests=$this->Fetch_model->get_all_lab_test_tests($a);//$user['phc_code']);

			return $lab_tests;
		}



}
?>
