<!DOCTYPE html>
<html>


          <?php
              require('side_menu.html');
          ?>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dental Treatment Report
            <small><?php echo date("d-M-Y"); ?></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">

            <ul class="nav nav-pills">
              <li class="active"><a data-toggle="pill" href="#home">Daily Report</a></li>
              <li><a data-toggle="pill" href="#menu2">Weekly Report</a></li>
              <li><a data-toggle="pill" href="#menu3">Monthly Report</a></li>
            </ul>

            <div class="tab-content">
                <div id="home" class="tab-pane fade in active">
                  <?php /*to get monthly and yearly
                  echo form_open('Add_details/drug_stocks');*/?>

                  <div class="box box-danger">
                    <button   class="btn btn-danger btn-md "style="position:fixed;flot:right"  onclick="printContent('wrapper')"><span class="glyphicon glyphicon-print"></span>Print</button>

                    <!-- form start -->
                    <div class="box-body">
                      <?php /*to get monthly and yearly
                      echo form_open('Add_details/drug_stocks');*/?>
                    <div class="pull-right">
                        <input type="text" id="pd1" class=" " name="date" value="" placeholder="Select Date" required="" autocomplete="off">
                        <button type="submit" id="pds1" value="Submit" name="submit" onclick="jsfun()"  class="btn btn-primary">
                          <span class="glyphicon glyphicon-search"></span></button>

                      <?php //form_close(); ?>
                    </div>
                    <div id="wrapper">
                    <table id="" class="examples display table table-striped table-bordered" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                           <td colspan="8">
                             <img src="<?php echo base_url();?>img/1.jpg" style="margin:0 0 0 0px;width:12%;float:left" alt="Niite Image">
                              <img src="<?php echo base_url();?>img/2.jpg" style="margin:0 0 0 0px;width:12%;float:right" alt="Nitte Image">
                              <center><span style=" font-size: 23px;"><b>JUSTICE K.S HEGDE CHARITABLE HOSPITAL</b></span><br/>
                              <span style="padding:0;margin:0;font-size: 20px;">DERALAKATTE-574100</span><br/>
                             <span style="padding:0px;margin:0;font-size: 16px;">Phone : 12345 ,Udupi</span><br/><br/>
                             <span style="padding:0;margin:0;clear:both;border:2px solid black;font-size: 28px;">DENTAL REPORT</span>
                           </center>
                           </td>
                        </tr>

                        <tr>
                            <th>SI No</th>
                          <!--  <th>Date</th>-->
                            <th>Patient ID</th>
                            <th>Name</th>
                            <th>Age</th>
                            <th>Place</th>
                            <th>Sex</th>
                          <!--  <th>Treatment Type</th>-->
                            <th>Diagonosis</th>
                          <!--  <th>Prescription</th>-->
                          </tr>
                        </thead>
                  <!--  <tfoot>
                            <tr>
                              <th>SI No</th>
                              <th>Date</th>
                              <th>Patient ID</th>
                              <th>Patient Name</th>
                              <th>Age</th>
                              <th>Sex</th>
                              <th>Complaints</th>

                              <th>Findings</th>
                              <th>Diagonosis</th>
                              <th>Investigation</th>
                              <th>Treatment</th>
                              <th>Reference</th>
                              <th>Prescription</th>


                            </tr>
                        </tfoot>-->
                        <tbody id="n">

                        </tbody>
                      </table>
                    </div>
                    </div><!-- /.box-body -->
                <!--  <div class="box-footer">
                          <input type="submit" value="submit" name="submit"  class="btn btn-primary">
                  </div>-->

                  </div><!-- /.box -->
                </div>
                <div id="menu2" class="tab-pane fade">
                  <div class="box box-danger">
                    <button   class="btn btn-danger btn-md "style="position:fixed;flot:right"  onclick="printContent('wrapper2')"><span class="glyphicon glyphicon-print"></span>Print</button>

                    <!-- form start -->
                    <div class="box-body">
                    <center>
                      <div class="">
                          <input type="text" id="pd2W" class=" " name="datefilter" value="" placeholder="Select Date" required="" autocomplete="off">
                          <button type="submit" id="pds2W" value="Submit" name="submit" onclick="jsfunW()"  class="btn btn-primary">
                          <span class="glyphicon glyphicon-search"></span></button>
                      </div>
                    </center>

                  <div id="wrapper2">
                    <table id="" class="examples display table table-striped table-bordered" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                           <td colspan="8">
                             <img src="<?php echo base_url();?>img/1.jpg" style="margin:0 0 0 0px;width:12%;float:left" alt="Niite Image">
                              <img src="<?php echo base_url();?>img/2.jpg" style="margin:0 0 0 0px;width:12%;float:right" alt="Nitte Image">
                              <center><span style=" font-size: 23px;"><b>JUSTICE K.S HEGDE CHARITABLE HOSPITAL</b></span><br/>
                              <span style="padding:0;margin:0;font-size: 20px;">DERALAKATTE-574100</span><br/>
                             <span style="padding:0px;margin:0;font-size: 16px;">Phone : 12345 ,Udupi</span><br/><br/>
                             <span style="padding:0;margin:0;clear:both;border:2px solid black;font-size: 28px;">DENTAL REPORT</span>
                           </center>
                           </td>
                        </tr>
                        <tr>
                            <th>SI No</th>
                          <!--  <th>Date</th>-->
                            <th>Patient ID</th>
                            <th>Name</th>
                            <th>Age</th>
                            <th>Place</th>
                            <th>Sex</th>
                             <th>Date of visit</th>
                            <th>Diagonosis</th>
                          <!--  <th>Prescription</th>-->
                          </tr>
                        </thead>
                  <!--  <tfoot>
                            <tr>
                              <th>SI No</th>
                              <th>Date</th>
                              <th>Patient ID</th>
                              <th>Patient Name</th>
                              <th>Age</th>
                              <th>Sex</th>
                              <th>Complaints</th>

                              <th>Findings</th>
                              <th>Diagonosis</th>
                              <th>Investigation</th>
                              <th>Treatment</th>
                              <th>Reference</th>
                              <th>Prescription</th>


                            </tr>
                        </tfoot>-->
                        <tbody id="W">

                        </tbody>
                      </table>
                    </div>
                    </div><!-- /.box-body -->
                <!--  <div class="box-footer">
                          <input type="submit" value="submit" name="submit"  class="btn btn-primary">
                  </div>-->

                  </div><!-- /.box -->
                </div>
                <div id="menu3" class="tab-pane fade">
                  <div class="box box-danger">
                    <button   class="btn btn-danger btn-md "style="position:fixed;flot:right"  onclick="printContent('wrapper3')"><span class="glyphicon glyphicon-print"></span>Print</button>

                    <!-- form start -->
                    <div class="box-body">
                      <center>
                        <div class="">

                            <input type="text" id="month" class=" " name="pd2M" value="" placeholder=" Select Month" required="" autocomplete="off">
                            <button type="submit" id="pds2M" value="Submit" name="submit" onclick="jsfunM()"  class="btn btn-primary">
                            <span class="glyphicon glyphicon-search"></span></button>

                        </div>
                      </center>
                    <div id="wrapper3">
                    <table id="" class="examples display table table-striped table-bordered" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                           <td colspan="8">
                             <img src="<?php echo base_url();?>img/1.jpg" style="margin:0 0 0 0px;width:12%;float:left" alt="Niite Image">
                              <img src="<?php echo base_url();?>img/2.jpg" style="margin:0 0 0 0px;width:12%;float:right" alt="Nitte Image">
                              <center><span style=" font-size: 23px;"><b>JUSTICE K.S HEGDE CHARITABLE HOSPITAL</b></span><br/>
                              <span style="padding:0;margin:0;font-size: 20px;">DERALAKATTE-574100</span><br/>
                             <span style="padding:0px;margin:0;font-size: 16px;">Phone : 12345 ,Udupi</span><br/><br/>
                             <span style="padding:0;margin:0;clear:both;border:2px solid black;font-size: 28px;">DENTAL REPORT</span>
                           </center>
                           </td>
                        </tr>
                        <tr>
                            <th>SI No</th>
                          <!--  <th>Date</th>-->
                            <th>Patient ID</th>
                            <th>Name</th>
                            <th>Age</th>
                            <th>Place</th>
                            <th>Sex</th>
                            <th>Date of visit</th>
                            <th>Diagonosis</th>
                          <!--  <th>Prescription</th>-->
                          </tr>
                        </thead>
                  <!--  <tfoot>
                            <tr>
                              <th>SI No</th>
                              <th>Date</th>
                              <th>Patient ID</th>
                              <th>Patient Name</th>
                              <th>Age</th>
                              <th>Sex</th>
                              <th>Complaints</th>

                              <th>Findings</th>
                              <th>Diagonosis</th>
                              <th>Investigation</th>
                              <th>Treatment</th>
                              <th>Reference</th>
                              <th>Prescription</th>


                            </tr>
                        </tfoot>-->
                        <tbody id="M">

                        </tbody>
                      </table>
                    </div>
                    </div><!-- /.box-body -->
                <!--  <div class="box-footer">
                          <input type="submit" value="submit" name="submit"  class="btn btn-primary">
                  </div>-->

                  </div><!-- /.box -->
                </div>
            </div>

          </div>
      </section><!-- /.content -->
      </div><!-- /.content-wrapper
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.3.0
        </div>
        <strong>Copyright &copy; 2017 .</strong> All rights reserved.
      </footer>-->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->

      </div><!-- ./wrapper -->

      <!-- jQuery 2.1.4 -->

      <script src="<?php echo base_url();?>plugins/jQuery/jQuery-2.1.4.min.js"></script>
      <!-- jQuery UI 1.11.4 -->
      <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />-->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.3.1/css/buttons.dataTables.min.css" />

      <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.print.min.js"></script>
      <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
      <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

      <script type="text/javascript">
      $( function() {
      $("#month").datepicker( {
         format: "mm",
        viewMode: "months",
        minViewMode: "months"

      });
        });
      /*----------------*/
      /* Custom filtering function which will search data in column four between two values */
  $.fn.dataTable.ext.search.push(
      function( settings, data, dataIndex ) {
          var min = parseInt( $('#min').val(), 10 );
          var max = parseInt( $('#max').val(), 10 );
          var age = parseFloat( data[4] ) || 0; // use data for the age column

          if ( ( isNaN( min ) && isNaN( max ) ) ||
               ( isNaN( min ) && age <= max ) ||
               ( min <= age   && isNaN( max ) ) ||
               ( min <= age   && age <= max ) )
          {
              return true;
          }
          return false;
      }
  );

  $(document).ready(function() {
      var table = $('.example').DataTable({
      "dom": 'li<"toolbar">frtBp',
       "scrollX": true,
      });

      // Event listener to the two range filtering inputs to redraw on input
      $('.min, .max').keyup( function() {
          table.draw();
      } );
  /*pick date start
  $("div.toolbar").html('<input id="date_range" type="text" class="col-md-3" placeholder="Pick Date">');
      //END of the data table

      // Date range script - Start of the sscript
      $("#date_range").daterangepicker({
       autoUpdateInput: false,
       locale: {
         "cancelLabel": "Clear",
              }
      });

      $("#date_range").on('apply.daterangepicker', function(ev, picker) {
            $(this).val(picker.startDate.format('YYYY-MM-DD') + ' to ' + picker.endDate.format('YYYY-MM-DD'));
         table.draw();
      });

      $("#date_range").on('cancel.daterangepicker', function(ev, picker) {
            $(this).val('');
         table.draw();
      });
      // Date range script - END of the script

      $.fn.dataTableExt.afnFiltering.push(
      function( oSettings, aData, iDataIndex ) {

       var grab_daterange = $("#date_range").val();
       var give_results_daterange = grab_daterange.split(" to ");
          var filterstart = give_results_daterange[0];
          var filterend = give_results_daterange[1];
          var iStartDateCol = 0; //using column 2 in this instance
          var iEndDateCol = 0;
          var tabledatestart = aData[iStartDateCol];
          var tabledateend= aData[iEndDateCol];

          if ( !filterstart && !filterend )
          {
              return true;
          }
          else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isBefore(tabledatestart)) && filterend === "")
          {
              return true;
          }
          else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isAfter(tabledatestart)) && filterstart === "")
          {
              return true;
          }
          else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isBefore(tabledatestart)) && (moment(filterend).isSame(tabledateend) || moment(filterend).isAfter(tabledateend)))
          {
              return true;
          }
          return false;
      }
    );
pick-date close
    */
  } );
  $(document).ready(function() {
       $( "#pd1" ).datepicker({
         setDate: new Date(),
         changeMonth: true,
         changeYear: true,
           format:'yyyy-mm-dd'
       });
     } );

     function jsfun(){
       var n=$("#pd1").val();
       if(n!=''){
       $.ajax({
       type: 'post',

       url: "<?php echo site_url('Add_details/dent_report_date');?>",
       data:{
         date:n,
       },
       success: function (response) {

         $( '#n').html(response);

          if(response=="OK")
          {
           return true;
          }
          else
          {
           return false;
          }
         }
       });
     }else{
       alert("PLease choose date")
     }
    }

     function jsfunW(){
       var n=$("#pd2W").val();
       if(n!=''){
       $.ajax({
       type: 'post',

       url: "<?php echo site_url('Add_details/dent_report_week');?>",
       data:{
         date:n,
       },
       success: function (response) {

         $( '#W').html(response);

          if(response=="OK")
          {
           return true;
          }
          else
          {
           return false;
          }
         }
       });
     }else{
       alert("PLease choose dates and click on apply in calendar")
     }
   }

     function jsfunM(){
       var n=$("#month").val();
 if(n!=''){

       $.ajax({
       type: 'post',

       url: "<?php echo site_url('Add_details/dent_report_month');?>",
       data:{
         date:n,
       },
       success: function (response) {

         $( '#M').html(response);

          if(response=="OK")
          {
           return true;
          }
          else
          {
           return false;
          }
         }
       });
     }else{
       alert("PLease choose month")
     }
     }


     $(function() {

       $('input[name="datefilter"]').daterangepicker({
           autoUpdateInput: false,
           locale: {
               cancelLabel: 'Clear'
           }
       });

       $('input[name="datefilter"]').on('apply.daterangepicker', function(ev, picker) {
           $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
       });

       $('input[name="datefilter"]').on('cancel.daterangepicker', function(ev, picker) {
           $(this).val('');
       });

     });


        /*----------------*/
        $(document).ready(function (){
          $.ajax({
          type: 'post',
          url: "<?php echo site_url('Fetch/notification');?>",

          success: function (response) {
            $( '#notification_count').html(response);
             if(response=="OK")
             {
              return true;
             }
             else
             {
              return false;
             }
            }
          });

        });

        $(document).ready(function (){
           var phc = $('#21').val();

          $.ajax({
          type: 'post',
          url: "<?php echo site_url('Fetch/notification1');?>",
          data:{
            p:phc,
          },
          success: function (response) {
            $( '#notification_count1').html(response);
             if(response=="OK")
             {
              return true;
             }
             else
             {
              return false;
             }
            }
          });

        });


/*-----old datatable code --------*/
/*----------------*/
/* Custom filtering function which will search data in column four between two values */
/* $.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = parseInt( $('#min').val(), 10 );
        var max = parseInt( $('#max').val(), 10 );
        var age = parseFloat( data[3] ) || 0; // use data for the age column

        if ( ( isNaN( min ) && isNaN( max ) ) ||
             ( isNaN( min ) && age <= max ) ||
             ( min <= age   && isNaN( max ) ) ||
             ( min <= age   && age <= max ) )
        {
            return true;
        }
        return false;
    }
);
$(document).ready( function () {
  var table = $('#example').DataTable({
$('#min, #max').keyup( function() {
 table.draw();
} );
});
});*/
  //Start of the data table
/*   $(document).ready( function () {
   var table = $('#example').DataTable({

     initComplete: function () {
         this.api().columns().every( function () {
             var column = this;
             var select = $('<select><option value="">Select</option></select>')
                 .appendTo( $(column.footer()).empty() )
                 .on( 'change', function () {
                     var val = $.fn.dataTable.util.escapeRegex(
                         $(this).val()
                     );

                     column
                         .search( val ? '^'+val+'$' : '', true, false )
                         .draw();
                 } );

             column.data().unique().sort().each( function ( d, j ) {
                 select.append( '<option value="'+d+'">'+d+'</option>' )
             } );
         } );
     },
     "dom": 'li<"toolbar">frtBp',
      "scrollX": true,


   });

 $("div.toolbar").html('<input id="date_range" type="text" class="col-md-3" placeholder="Pick Date">');
 //END of the data table

 // Date range script - Start of the sscript
 $("#date_range").daterangepicker({
  autoUpdateInput: false,
  locale: {
    "cancelLabel": "Clear",
         }
 });

 $("#date_range").on('apply.daterangepicker', function(ev, picker) {
       $(this).val(picker.startDate.format('YYYY-MM-DD') + ' to ' + picker.endDate.format('YYYY-MM-DD'));
    table.draw();
 });

 $("#date_range").on('cancel.daterangepicker', function(ev, picker) {
       $(this).val('');
    table.draw();
 });
 // Date range script - END of the script

 $.fn.dataTableExt.afnFiltering.push(
 function( oSettings, aData, iDataIndex ) {

  var grab_daterange = $("#date_range").val();
  var give_results_daterange = grab_daterange.split(" to ");
     var filterstart = give_results_daterange[0];
     var filterend = give_results_daterange[1];
     var iStartDateCol = 0; //using column 2 in this instance
     var iEndDateCol = 0;
     var tabledatestart = aData[iStartDateCol];
     var tabledateend= aData[iEndDateCol];

     if ( !filterstart && !filterend )
     {
         return true;
     }
     else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isBefore(tabledatestart)) && filterend === "")
     {
         return true;
     }
     else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isAfter(tabledatestart)) && filterstart === "")
     {
         return true;
     }
     else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isBefore(tabledatestart)) && (moment(filterend).isSame(tabledateend) || moment(filterend).isAfter(tabledateend)))
     {
         return true;
     }
     return false;
 }
 );

 //End of the datable
});*/


/***************/
function printContent(el){
  var restorepage = document.body.innerHTML;
  var printcontent = document.getElementById(el).innerHTML;
  document.body.innerHTML = printcontent;
  window.print();
  document.body.innerHTML = restorepage;
}


      </script>

      <!-- Bootstrap 3.3.5-->
      <script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
      <!-- Morris.js charts -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
      <!--  <script src="<?php echo base_url();?>plugins/morris/morris.min.js"></script>-->
      <!-- Sparkline -->
      <script src="<?php echo base_url();?>plugins/sparkline/jquery.sparkline.min.js"></script>
      <!-- jvectormap -->
      <script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
      <script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
      <!-- jQuery Knob Chart -->
      <script src="<?php echo base_url();?>plugins/knob/jquery.knob.js"></script>
      <!-- daterangepicker -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
      <script src="<?php echo base_url();?>plugins/daterangepicker/daterangepicker.js"></script>
      <!-- datepicker -->
      <script src="<?php echo base_url();?>plugins/datepicker/bootstrap-datepicker.js"></script>
      <!-- Bootstrap WYSIHTML5 -->
      <script src="<?php echo base_url();?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
      <!-- Slimscroll -->
      <script src="<?php echo base_url();?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url();?>plugins/fastclick/fastclick.min.js"></script>
      <!-- AdminLTE App -->
      <script src="<?php echo base_url();?>dist/js/app.min.js"></script>
      <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!--  <script src="<?php echo base_url();?>dist/js/pages/dashboard.js"></script>-->
      <!-- AdminLTE for demo purposes -->
      <script src="<?php echo base_url();?>dist/js/demo.js"></script>

      <style>
      @media print
      {
        header  {
            visibility: hidden;
            margin-top:0px;
            padding-top:0px;
        }



        thead {display: table-header-group;}

      }
        /*    .break-word {
            width: 20em;
          background: lime;
            color:black;
            overflow-wrap: break-word;
          }
          .break-word:hover{
            font-size: 20px;
            color:red;
          }*/
      </style>
  </body>

</html>
