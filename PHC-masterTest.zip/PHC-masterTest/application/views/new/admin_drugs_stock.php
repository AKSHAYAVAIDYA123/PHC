<!DOCTYPE html>
<html>


          <?php
              require('side_menu.html');
          ?>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Medicine Stock Register
            <small>Medicine Stock Details</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="box box-primary">

              <!-- form start -->
              <div class="box-body">
                <div class="form-group pull-right">
                  <?php
                  echo form_open('Add_details/admin_drug_stocks_by_date');?>
                    <input type="text" id="pd1" class=" " name="date" value="" placeholder="Select Date" required="" autocomplete="off">
                    <select  name="phc" required>
                       <option value="">Select PHC</option>
                        <?php foreach($phc as $each){ ?>
                             <option value="<?php echo $each->phc_code; ?>"><?php echo $each->phc_name; ?></option>
                         <?php } ?>
                    </select>
                    <button type="submit" id="pds1" value="Submit" name="submit"  class="btn btn-primary">
                      <span class="glyphicon glyphicon-search"></span></button>

                  <?php form_close(); ?>

                  </div>
              <button   class="btn btn-primary btn-md "style="position:fixed;flot:right"  onclick="printContent('wrapper')"><span class="glyphicon glyphicon-print"></span>Print</button>

              <div id="wrapper">
                <table id="example12" class="table table-striped table-bordered" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                       <td colspan="6">
                         <img src="<?php echo base_url();?>img/1.jpg" style="margin:0 0 0 0px;width:12%;float:left" alt="Niite Image">
                          <img src="<?php echo base_url();?>img/2.jpg" style="margin:0 0 0 0px;width:12%;float:right" alt="Nitte Image">
                          <center><span style=" font-size: 23px;"><b>JUSTICE K.S HEGDE CHARITABLE HOSPITAL</b></span><br/>
                          <span style="padding:0;margin:0;font-size: 20px;">DERALAKATTE-574100</span><br/>
                         <span style="padding:0px;margin:0;font-size: 16px;">Phone : 12345 ,Udupi</span><br/><br/>
                         <span style="padding:0;margin:0;clear:both;border:2px solid black;font-size: 28px;">DRUGS STOCK REGISTER</span>
                       </center>
                       </td>
                    </tr>

                      <tr>

                      <th>Medicine Name</th>
                      <th>Opening Balance</th>
                      <th>Utilised</th>
                      <th>Quantity Requested</th>
                      <th>Quantity Received</th>
                      <th>Closing Balance</th>
                      </tr>
                  </thead>
              <!--    <tfoot style="position:">
                      <tr>

                        <tr>

                        <th>Medicine Name</th>
                        <th>Opening Balance</th>
                        <th>Utilised</th>
                        <th>Quantity Requested</th>
                        <th>Quantity Received</th>
                        <th>Closing Balance</th>
                        </tr>
                      </tr>
                  </tfoot>
                -->
                  <tbody ><?php
                    if(isset($stock)&&!empty($stock)){

                				 foreach ($stock as $row) {
                					 ?>
                					 <tr>
                						 <td><?php echo $row['drug_name']; ?></td>
                						 <td><?php echo $row['op_bal']; ?></td>
                						 <td><?php echo $row['qty_utilised']; ?></td>
                						 <td><?php echo $row['qty_requested']; ?></td>
                						 <td><?php echo $row['qty_added']; ?></td>
                						 <td><?php echo $row['cl_bal']; ?></td>
                						</tr>
                					 <?php
                							 }
                						 }
                						?>
                  </tbody>

                </table>

              </div>


              </div><!-- /.box-body -->
          <!--  <div class="box-footer">
                    <input type="submit" value="submit" name="submit"  class="btn btn-primary">
            </div>-->

            </div><!-- /.box -->
          </div>




        </section><!-- /.content -->
      </div><!-- /.content-wrapper
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.3.0
        </div>
        <strong>Copyright &copy; 2017 .</strong> All rights reserved.
      </footer>-->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
      </div><!-- ./wrapper -->

      <!-- jQuery 2.1.4 -->

      <script src="<?php echo base_url();?>plugins/jQuery/jQuery-2.1.4.min.js"></script>
      <!-- jQuery UI 1.11.4 -->
      <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />-->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.3.1/css/buttons.dataTables.min.css" />

      <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.print.min.js"></script>
      <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
      <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

      <script type="text/javascript">
  /* for monthly & year calendar
  $( function() {
      $("#pd1").datepicker( {
                  viewMode: "months",
          minViewMode: "months",
          format: "yyyy-mm"

      });
    });*/

        $(document).ready(function() {
             $( "#pd1" ).datepicker({
               setDate: new Date(),
               changeMonth: true,
               changeYear: true,
                 format:'yyyy-mm-dd'
             });
           } );


      /*  function jsfun(){
          var n=$("#pd1").val();

          $.ajax({
          type: 'post',
          //url: "<?php echo site_url('Add_details/drug_stocks');?>",      // monthly & yearly//
          url: "<?php echo site_url('Add_details/drug_stocks_by_date');?>",
          data:{
            date:n,
          },
          success: function (response) {

            $( '#n').html(response);

             if(response=="OK")
             {
              return true;
             }
             else
             {
              return false;
             }
            }
          });
        }*/

/*--------------
      $(document).ready(function(){

       $("#pds").click(function(){

          var n=$("#pd").val();
         $.ajax({
         type: "POST",
         url: "<?php echo site_url('Add_details/index5');?>",
         data:{
           keyword:n,
           },

         success: function(data){
            $("#sdat1").hide();
           $("#sdat2").html(data);

         }
         });
       });
      });*/
      /*----------------*/
    /*  $(document).ready(function() {
          $('#example1').DataTable({
        	"dom": 'fitBp'
          });
      } );*/
      /************/
      $(document).ready(function (){
        $.ajax({
        type: 'post',
        url: "<?php echo site_url('Fetch/notification');?>",

        success: function (response) {
          $( '#notification_count').html(response);
           if(response=="OK")
           {
            return true;
           }
           else
           {
            return false;
           }
          }
        });

      });

      $(document).ready(function (){
         var phc = $('#21').val();

        $.ajax({
        type: 'post',
        url: "<?php echo site_url('Fetch/notification1');?>",
        data:{
          p:phc,
        },
        success: function (response) {
          $( '#notification_count1').html(response);
           if(response=="OK")
           {
            return true;
           }
           else
           {
            return false;
           }
          }
        });

      });
/***************/
function printContent(el){
  var restorepage = document.body.innerHTML;
  var printcontent = document.getElementById(el).innerHTML;
  document.body.innerHTML = printcontent;
  window.print();
  document.body.innerHTML = restorepage;
}
      </script>

      <!-- Bootstrap 3.3.5-->
      <script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
      <!-- Morris.js charts -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <!--     <script src="<?php echo base_url();?>plugins/morris/morris.min.js"></script>-->
      <!-- Sparkline -->
      <script src="<?php echo base_url();?>plugins/sparkline/jquery.sparkline.min.js"></script>
      <!-- jvectormap -->
      <script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
      <script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
      <!-- jQuery Knob Chart -->
      <script src="<?php echo base_url();?>plugins/knob/jquery.knob.js"></script>
      <!-- daterangepicker -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
      <script src="<?php echo base_url();?>plugins/daterangepicker/daterangepicker.js"></script>
      <!-- datepicker -->
      <script src="<?php echo base_url();?>plugins/datepicker/bootstrap-datepicker.js"></script>
      <!-- Bootstrap WYSIHTML5 -->
      <script src="<?php echo base_url();?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
      <!-- Slimscroll -->
      <script src="<?php echo base_url();?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url();?>plugins/fastclick/fastclick.min.js"></script>
      <!-- AdminLTE App -->
      <script src="<?php echo base_url();?>dist/js/app.min.js"></script>
      <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
      <!--  <script src="<?php echo base_url();?>dist/js/pages/dashboard.js"></script>-->
      <!-- AdminLTE for demo purposes -->
      <script src="<?php echo base_url();?>dist/js/demo.js"></script>


  </body>
  <style>

  @media print
  {
    header  {
        visibility: hidden;
        margin-top:0px;
        padding-top:0px;
    }



    thead {display: table-header-group;}

  }
  </style>
</html>
