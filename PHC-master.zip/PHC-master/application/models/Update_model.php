<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Update_model extends CI_Model
{
	function __construct()
    {
        parent::__construct();

    }
function update_history($data,$id)
{
	 $this->db->where('pat_id',$id);
	if( $this->db->update('patient_record',$data))
			 {
				 return 1;
			 }
			 else
			 {
				 return 0;
			 }
}

	function update_user($data,$id)
	{
    $this->db->where('user_id',$id);
    if( $this->db->update('users',$data))
         {
           return 1;
         }
         else
         {
           return 0;
         }
  }

  function delete_user($id)
	{
    $this->db->where('user_id',$id);
    if( $this->db->delete('users'))
         {
           return 1;
         }
         else
         {
           return 0;
         }
  }
	function update_phc($data,$id)
	{
		$this->db->where('phc_id',$id);
		if( $this->db->update('phc',$data))
				 {
					 return 1;
				 }
				 else
				 {
					 return 0;
				 }
	}
	function delete_phc($id)
	{
    $this->db->where('phc_id',$id);
    if( $this->db->delete('phc'))
         {
           return 1;
         }
         else
         {
           return 0;
         }
  }

	function update_drugs($data,$id)
	{
		$this->db->where('drug_id',$id);
		if( $this->db->update('all_drugs',$data))
				 {
					 return 1;
				 }
				 else
				 {
					 return 0;
				 }
	}


	function delete_drugs($id,$data)
	{

				 $this->db->where('drug_id',$id);
	 			if( $this->db->update('all_drugs',$data))
	 					 {
	 						 return 1;
	 					 }
	 					 else
	 					 {
	 						 return 0;
	 					 }
	}

	function update_tests($data,$id)
	{
		$this->db->where('test_id',$id);
		if( $this->db->update('tests',$data))
				 {
					 return 1;
				 }
				 else
				 {
					 return 0;
				 }
	}
	function delete_tests($id,$data)
	{

				 $this->db->where('test_id',$id);
				if( $this->db->update('tests',$data))
						 {
							 return 1;
						 }
						 else
						 {
							 return 0;
						 }
	}

}
?>
