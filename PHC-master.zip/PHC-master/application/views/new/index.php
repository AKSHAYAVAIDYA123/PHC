<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SMART PHC</title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <!-- Theme style -->
     <link rel="stylesheet" href="<?php echo base_url();?>css/slider style.css">
     <!-- iCheck -->
     <link rel="stylesheet" href="<?php echo base_url();?>css/style.css">
   <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css">
     <!-- iCheck -->
     <link rel="stylesheet" href="<?php echo base_url();?>css/animate.css">
  <link rel="stylesheet" href="<?php echo base_url();?>css/owl.theme.css" media="screen">
  <link rel="stylesheet" href="<?php echo base_url();?>css/owl.carousel.css" media="screen">
 <link rel="stylesheet" href="<?php echo base_url();?>css/nivo-lightbox-theme/default/default.css" type="text/css">
     <!-- iCheck -->
     <link rel="stylesheet" href="<?php echo base_url();?>css/nivo-lightbox.css">
<link rel="stylesheet" href="<?php echo base_url();?>font-awesome/css/font-awesome.min.css" type="text/css">
     <!-- iCheck -->
     <link rel="stylesheet" href="<?php echo base_url();?>plugins/cubeportfolio/css/cubeportfolio.min.css">
     <!-- Font Awesome -->
    <!-- Theme style -->
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo base_url();?>dist/css/AdminLTE.min.css">
     <!-- iCheck -->
     <link rel="stylesheet" href="<?php echo base_url();?>plugins/iCheck/square/blue.css">
 <link rel="stylesheet" href="<?php echo base_url();?>bodybg/bg1.css" id="bodybg">
     <!-- iCheck -->
     <link rel="stylesheet" href="<?php echo base_url();?>color/default.css" id="t-colors">

  <!-- boxed bg -->
  </head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">


  <div id="wrapper">

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
    
      <div class="container navigation">

        <div class="navbar-header page-scroll">
        
                    <a href="/PHC-master/img/logo.png" >
                       <img src="/PHC-master/img/logo.png" alt="" width="150" height="60">
         
                  
          </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#intro">Home</a></li>
            <li><a href="#service">Service</a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal">Login</a></li>
            <li><a href="#footer1">Contact Us</a></li>
           </ul>
        </div>
        <!-- /.navbar-collapse -->
      </div>
      <!-- /.container -->
    </nav>

    <!-- Section: intro -->
    <section id="intro" class="intro">
      <div >
      <div id="slider"   >
<figure>
  <img src="<?php base_url(); ?>"  >
<img src="" >
  <a href="/PHC-master/images/1.jpg" >
        <img src="/PHC-master/images/1.jpg" alt="Lights" height="600" width="100%">
         <a href="/PHC-master/images/3.jpg" ></a>
        <img src="/PHC-master/images/3.jpg" alt="Lights" height="600" width="100%">
         <a href="/PHC-master/images/4.jpg" ></a>
        <img src="/PHC-master/images/4.jpg" alt="Lights" height="600" width="100%">
         <a href="/PHC-master/images/6.jpg" ></a>
        <img src="/PHC-master/images/6.jpg" alt="Lights" height="600" width="100%">
         <a href="/PHC-master/images/index.jpg" ></a>
        <img src="/PHC-master/images/index.jpg" alt="Lights" height="600" width="100%">
 
</figure> 
 

      </div>
    </div>
    </section>
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
       <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                  <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
                </button>
                <h3 class="modal-title" id="modal-login-label">Primary Health Center</h3>
                <p>Sign in to start your session</p>
              </div>
              
              <div class="modal-body">
            <div class="login-box-body">
        <p class="login-box-msg">Sign in to start your session</p>
        <?php if (isset($error) && !empty($error)) {
                      echo "<script>alert('" . $error . "')</script>";
                    }
                   echo form_open('Login/index'); ?>
          <div class="form-group has-feedback">
          <input type="email" name="email" id="email" Placeholder="Enter Your Email" class="form-control input-md"  required="">
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" name="pass" id="pass" Placeholder="Enter Password" class="form-control input-md" data-rule="password" data-msg="Please enter a valid password" required="">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-xs-8">

            </div><!-- /.col -->
            <div class="col-xs-4">
               <input type="submit" value="Login" name="login" class="btn btn-primary btn-block btn-flat">

            </div><!-- /.col -->
          </div>

      <!-- <?php form_close(); ?>-->



    
        <a href="#">I forgot my password</a><br>


      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->
</div>
</div>
</div>
    <!-- jQuery 2.1.4 -->
    <script src="<?php echo base_url();?>plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url();?>plugins/iCheck/icheck.min.js"></script>
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
    </script>

        <!-- Javascript -->
      


    <!-- Section: team -->
 <section id="service" class="home-section nopadding paddingtop-60">

      <div class="container">
<caption><center><h1><b>Services</b></h1></center></caption>
   <div class="row">
      <div class="row">

          <div class="col-md-1">
          </div>
          <div class="col-md-3">
            <br>
            <br>
            <br>
          
            <div class="wow fadeInRight" data-wow-delay="0.2s">
              <div class="service-box">
                <div class="service-icon">
                  <span class="fa fa-wheelchair fa-3x"> Hosipital</span>
                </div>
               
              </div>
            </div>
            <br>
            <br>
                <div class="wow fadeInRight" data-wow-delay="0.3s">
              <div class="service-box">
                <div class="service-icon">
           <span class="fa fa-medkit fa-3x"> Pharmacy</span>
                </div>
               
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <br>
            <br>
            <br>
            <div class="wow fadeInRight" data-wow-delay="0.2s">
              <div class="service-box">
                <div class="service-icon">
                  <span class="fa fa-h-square fa-3x"> Dental</span>
                </div>
               
              </div>
            </div>
            <br>
            <br>
                <div class="wow fadeInRight" data-wow-delay="0.3s">
              <div class="service-box">
                <div class="service-icon">
           <span class="fa fa-user-md fa-3x"> Psychiatry</span>
                </div>
               
              </div>
            </div>
          </div>
         <div class="col-md-4">
                    <div >
   <figure>
               <img src="<?php base_url(); ?>"  >
<img src="" >
                <a href="/PHC-master/images/a1.jpg">  <img src="/PHC-master/images/a1.jpg" class="img-responsive" alt="" height="600" width="100%"></a>
        </figure>
        </div>
      </div>
    </div>
      
   
   </section>
   
    
    <footer id="footer1">

      <div class="container">
    <center>  <caption><h3><b>DEVELOPED BY</h3></b></caption>
        <div class="row">
          <div  class="col-md-3">
          </div>
          <div class="col-md-3">
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
             &nbsp&nbsp&nbsp&nbsp 
               <img src="/PHC-master/img/index.jpg" height="120" width="120">
         <a href="/PHC-master/img/index.jpg" ></a>
              </div>
            </div>
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
                <h5>Anantha Murthy</h5>
                <ul>
                  <li>Ass. Professor</li>
                  <li>Department of MCA</li>
                  <li>NMAMIT NITTE</li>
                  <li>9743702262</li>
        
                </ul>
              </div>
            </div>
          </div>
       
          <div class="col-md-3">
              <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
             &nbsp&nbsp&nbsp&nbsp  <img src="/PHC-master/img/index1.jpg"  height="120" width="120">
         <a href="/PHC-master/img/index1.jpg" ></a>
              </div>
            </div>
            <div class="wow fadeInDown" data-wow-delay="0.1s">
              <div class="widget">
                <h5>Punith Kumar </h5>
                <ul>
                  <li>6th Sem</li>
                  <li>4NM15mca55</li>
                 <li> MCA</li>
                  <li>NMAMIT NITTE</li>
               
                </ul>
              </div>
            </div>
         
          </div>
          <div class="col-md-3"></div>
        </div>
      </div>
      
    </footer>

  </div>
  <a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

  <!-- Core JavaScript Files -->
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/jquery.scrollTo.js"></script>
  <script src="js/jquery.appear.js"></script>
  <script src="js/stellar.js"></script>
  <script src="plugins/cubeportfolio/js/jquery.cubeportfolio.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/nivo-lightbox.min.js"></script>
  <script src="js/custom.js"></script>

</body>

</html>
